"""
database.py – Database connection and stored procedure wrapper for SHMS
All DB operations go through stored procedures or views.
"""

import pymysql
import pymysql.cursors
from flask import current_app, g


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------

def get_db():
    """Return a connection stored in Flask's g object (one per request)."""
    if 'db' not in g:
        g.db = pymysql.connect(
            host=current_app.config['MYSQL_HOST'],
            port=current_app.config['MYSQL_PORT'],
            user=current_app.config['MYSQL_USER'],
            password=current_app.config['MYSQL_PASSWORD'],
            database=current_app.config['MYSQL_DB'],
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True,
            charset='utf8mb4'
        )
    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _call_proc(proc_name, args=()):
    """Call a stored procedure and return all result sets."""
    conn = get_db()
    with conn.cursor() as cur:
        cur.callproc(proc_name, args)
        results = []
        while True:
            rows = cur.fetchall()
            if rows is not None:
                results.append(rows)
            if not cur.nextset():
                break
        conn.commit()
    return results


def _call_proc_out(proc_name, in_args, out_count):
    """
    Call a stored procedure with OUT parameters.
    Fetches OUT params via SELECT @_<proc>_<n> syntax.
    Returns (result_rows_list, out_params_list).
    """
    conn = get_db()
    with conn.cursor() as cur:
        placeholders = ', '.join(['%s'] * len(in_args) + [f'@out{i}' for i in range(out_count)])
        cur.execute(f'CALL {proc_name}({placeholders})', in_args)
        result_sets = []
        while True:
            rows = cur.fetchall()
            if rows is not None:
                result_sets.append(rows)
            if not cur.nextset():
                break
        # Fetch OUT params
        out_selects = ', '.join([f'@out{i}' for i in range(out_count)])
        cur.execute(f'SELECT {out_selects}')
        out_row = cur.fetchone()
        out_params = list(out_row.values()) if out_row else [None] * out_count
        conn.commit()
    return result_sets, out_params


def _query_view(view_name, where_clause='', params=()):
    """SELECT from a view with optional WHERE."""
    conn = get_db()
    sql = f'SELECT * FROM {view_name}'
    if where_clause:
        sql += f' WHERE {where_clause}'
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def _raw_query(sql, params=()):
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def _raw_query_one(sql, params=()):
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchone()


def _raw_execute(sql, params=()):
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(sql, params)
    conn.commit()


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def db_login(email):
    """Returns user row dict or None."""
    results = _call_proc('sp_Login', (email,))
    if results and results[0]:
        return results[0][0]
    return None


# ---------------------------------------------------------------------------
# Student operations
# ---------------------------------------------------------------------------

def db_mark_attendance(student_id, gps, lat, lon, selfie_path):
    _, outs = _call_proc_out('sp_MarkAttendance',
                             (student_id, gps, lat, lon, selfie_path), 1)
    return outs[0]


def db_get_student_dashboard(student_id):
    results = _call_proc('sp_GetStudentDashboard', (student_id,))
    data = {
        'profile':      results[0][0] if results[0] else {},
        'today_att':    results[1][0] if len(results) > 1 and results[1] else None,
        'att_history':  results[2]    if len(results) > 2 else [],
        'room':         results[3][0] if len(results) > 3 and results[3] else None,
        'active_exit':  results[4][0] if len(results) > 4 and results[4] else None,
        'unread_count': results[5][0]['UnreadCount'] if len(results) > 5 and results[5] else 0,
        'att_pct':      results[6][0]['AttendancePct'] if len(results) > 6 and results[6] else 0,
    }
    # Detect if student is still using the default temp password
    from werkzeug.security import check_password_hash
    pw_row = _raw_query_one('SELECT PasswordHash FROM User WHERE UserID=%s', (student_id,))
    if pw_row:
        try:
            using_temp = check_password_hash(pw_row['PasswordHash'], 'namal123')
        except Exception:
            using_temp = False
        if data.get('profile'):
            data['profile']['UsingTempPassword'] = using_temp
    return data


def db_submit_exit(student_id, destination, is_leave, reason, departure, expected_return):
    _, outs = _call_proc_out('sp_SubmitExitApplication',
                             (student_id, destination, is_leave, reason, departure, expected_return), 2)
    return outs[0], outs[1]   # result_msg, app_id


def db_submit_complaint(student_id, title, description, ctype):
    _, outs = _call_proc_out('sp_SubmitComplaint',
                             (student_id, title, description, ctype), 1)
    return outs[0]


def db_update_profile(student_id, phone, photo_path):
    _, outs = _call_proc_out('sp_UpdateStudentProfile',
                             (student_id, phone, photo_path), 1)
    return outs[0]


def db_change_password(user_id, new_hash):
    _, outs = _call_proc_out('sp_ChangePassword', (user_id, new_hash), 1)
    return outs[0]


def db_get_notifications(user_id):
    return _raw_query(
        'SELECT * FROM Notification WHERE UserID = %s ORDER BY SentAt DESC LIMIT 50',
        (user_id,)
    )


def db_mark_notifications_read(user_id):
    _raw_execute('UPDATE Notification SET IsRead = 1 WHERE UserID = %s', (user_id,))


def db_get_attendance_history(student_id, days=30):
    return _raw_query(
        '''SELECT Date, Status FROM AttendanceRecord
           WHERE StudentID = %s AND Date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
           ORDER BY Date DESC''',
        (student_id, days)
    )


def db_record_exit_log(student_id, app_id, exit_time, selfie_path):
    _raw_execute(
        '''INSERT INTO EntryExitLog (ApplicationID, StudentID, ExitTime, SelfiePath)
           VALUES (%s, %s, %s, %s)
           ON DUPLICATE KEY UPDATE ExitTime = %s, SelfiePath = %s''',
        (app_id, student_id, exit_time, selfie_path, exit_time, selfie_path)
    )


# ---------------------------------------------------------------------------
# Warden operations
# ---------------------------------------------------------------------------

def db_get_pending_exits():
    return _query_view('vw_PendingExits')


def db_approve_exit(app_id, warden_id, action, remarks):
    _, outs = _call_proc_out('sp_ApproveExit',
                             (app_id, warden_id, action, remarks), 1)
    return outs[0]


def db_get_pending_complaints():
    return _raw_query(
        '''SELECT c.*, u.Name AS StudentName, s.RollNumber
           FROM Complaint c
           JOIN Student s ON c.StudentID = s.StudentID
           JOIN User u    ON s.StudentID = u.UserID
           WHERE c.Status IN ('Pending','In Progress')
           ORDER BY c.SubmittedAt DESC'''
    )


def db_get_all_complaints():
    return _raw_query(
        '''SELECT c.*, u.Name AS StudentName, s.RollNumber
           FROM Complaint c
           JOIN Student s ON c.StudentID = s.StudentID
           JOIN User u    ON s.StudentID = u.UserID
           ORDER BY c.SubmittedAt DESC'''
    )


def db_resolve_complaint(complaint_id, warden_id, status, remarks):
    _, outs = _call_proc_out('sp_ResolveComplaint',
                             (complaint_id, warden_id, status, remarks), 1)
    return outs[0]


def db_get_absent_today():
    return _query_view('vw_AbsentToday')


def db_get_students_on_leave():
    """Students currently on approved leave and NOT yet returned."""
    return _raw_query(
        '''SELECT ea.*, u.Name AS StudentName, s.RollNumber
           FROM ExitApplication ea
           JOIN Student s ON ea.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           WHERE ea.IsOnLeave = 1
             AND ea.ApprovalStatus IN ('Approved','Active')
           ORDER BY ea.DepartureTime DESC'''
    )


def db_get_returned_today():
    """Students who returned today – for warden view."""
    return _raw_query(
        '''SELECT ea.StudentID, u.Name AS StudentName, s.RollNumber,
                  ea.Destination, ea.IsOnLeave,
                  eel.ExitTime, eel.ActualReturnTime, eel.LateReturnAlert,
                  ea.ApplicationID
           FROM ExitApplication ea
           JOIN Student s          ON ea.StudentID = s.StudentID
           JOIN User u             ON s.StudentID  = u.UserID
           JOIN EntryExitLog eel   ON eel.ApplicationID = ea.ApplicationID
           WHERE DATE(eel.ActualReturnTime) = CURDATE()
             AND eel.ActualReturnTime IS NOT NULL
           ORDER BY eel.ActualReturnTime DESC'''
    )


def db_get_all_allocations():
    return _query_view('vw_CurrentAllocations')


def db_allocate_room(student_id, room_id, warden_id):
    _, outs = _call_proc_out('sp_AllocateRoom',
                             (student_id, room_id, warden_id), 1)
    return outs[0]


def db_get_rooms():
    return _raw_query('SELECT * FROM Room ORDER BY RoomNumber')


def db_get_all_exit_apps():
    return _raw_query(
        '''SELECT ea.*, u.Name AS StudentName, s.RollNumber
           FROM ExitApplication ea
           JOIN Student s ON ea.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           ORDER BY ea.SubmittedAt DESC LIMIT 100'''
    )


# ---------------------------------------------------------------------------
# Security operations
# ---------------------------------------------------------------------------

def db_get_security_gate():
    return _query_view('vw_SecurityGate')


def db_get_gate_history(limit=200):
    return _query_view('vw_GateHistory')


def db_delete_gate_history(log_id, admin_id):
    try:
        _raw_execute('DELETE FROM EntryExitLog WHERE LogID = %s', (log_id,))
        _raw_execute(
            '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
               VALUES (%s, 'DELETE', 'EntryExitLog', %s, 'Admin deleted gate history record')''',
            (admin_id, log_id)
        )
        return 'History record deleted.'
    except Exception as e:
        return f'ERROR: {str(e)}'


def db_confirm_student_exit(app_id, student_id):
    from datetime import datetime
    now = datetime.now()
    _raw_execute(
        '''INSERT INTO EntryExitLog (ApplicationID, StudentID, ExitTime)
           VALUES (%s, %s, %s)
           ON DUPLICATE KEY UPDATE ExitTime = %s''',
        (app_id, student_id, now, now)
    )
    _raw_execute(
        "UPDATE ExitApplication SET ApprovalStatus='Active' WHERE ApplicationID=%s",
        (app_id,)
    )


def db_record_return(student_id, app_id):
    _, outs = _call_proc_out('sp_RecordReturn', (student_id, app_id), 1)
    return outs[0]


# ---------------------------------------------------------------------------
# Admin operations
# ---------------------------------------------------------------------------

def db_get_all_students():
    results = _call_proc('sp_GetAllStudents')
    return results[0] if results else []


def db_add_student(name, email, pw_hash, phone, roll, dept, sem, admin_id):
    _, outs = _call_proc_out('sp_AddStudent',
                             (name, email, pw_hash, phone, roll, dept, sem, admin_id), 1)
    return outs[0]


def db_update_student(student_id, name, email, phone, roll, dept, sem, admin_id):
    _, outs = _call_proc_out('sp_UpdateStudent',
                             (student_id, name, email, phone, roll, dept, sem, admin_id), 1)
    return outs[0]


def db_delete_student(student_id, admin_id):
    _, outs = _call_proc_out('sp_DeleteStudent', (student_id, admin_id), 1)
    return outs[0]


def db_get_warden():
    return _raw_query_one(
        '''SELECT u.UserID, u.Name, u.Email, u.Phone, w.OfficePhone, w.HireDate
           FROM User u JOIN Warden w ON u.UserID = w.WardenID LIMIT 1'''
    )


def db_update_warden_password(warden_id, new_hash, admin_id):
    _, outs = _call_proc_out('sp_UpdateWardenPassword',
                             (warden_id, new_hash, admin_id), 1)
    return outs[0]


def db_update_warden_info(warden_id, name, phone, office_phone, admin_id):
    _raw_execute('UPDATE User SET Name=%s, Phone=%s WHERE UserID=%s',
                 (name, phone, warden_id))
    _raw_execute('UPDATE Warden SET OfficePhone=%s WHERE WardenID=%s',
                 (office_phone, warden_id))
    _raw_execute(
        '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
           VALUES (%s, 'UPDATE', 'Warden', %s, 'Warden info updated by admin')''',
        (admin_id, warden_id)
    )


def db_get_geofence():
    results = _call_proc('sp_GetGeofenceConfig')
    return results[0][0] if results and results[0] else None


def db_update_geofence(geo_id, name, lat, lon, radius, admin_id):
    _, outs = _call_proc_out('sp_UpdateGeofenceConfig',
                             (geo_id, name, lat, lon, radius, admin_id), 1)
    return outs[0]


def db_get_system_logs(limit=100):
    return _raw_query(
        '''SELECT scl.*, u.Name AS AdminName
           FROM SystemChangeLog scl
           JOIN SystemAdministrator sa ON scl.AdminID = sa.AdminID
           JOIN User u ON sa.AdminID = u.UserID
           ORDER BY scl.ChangeTime DESC LIMIT %s''',
        (limit,)
    )


def db_get_dashboard_stats():
    return _raw_query_one(
        '''SELECT
               (SELECT COUNT(*) FROM Student s JOIN User u ON s.StudentID=u.UserID WHERE u.IsActive=1) AS TotalStudents,
               (SELECT COUNT(*) FROM Room) AS TotalRooms,
               (SELECT COUNT(*) FROM Room WHERE RoomStatus='Available') AS AvailableRooms,
               (SELECT COUNT(*) FROM AttendanceRecord WHERE Date=CURDATE() AND Status='Present') AS PresentToday,
               (SELECT COUNT(*) FROM AttendanceRecord WHERE Date=CURDATE() AND Status='Absent') AS AbsentToday,
               (SELECT COUNT(*) FROM ExitApplication WHERE ApprovalStatus='Pending') AS PendingExits,
               (SELECT COUNT(*) FROM Complaint WHERE Status='Pending') AS PendingComplaints'''
    )


# ---------------------------------------------------------------------------
# Room management (Admin)
# ---------------------------------------------------------------------------

def db_add_room(room_number, capacity, admin_id):
    try:
        _raw_execute(
            'INSERT INTO Room (RoomNumber, Capacity, CurrentOccupancy, RoomStatus) VALUES (%s, %s, 0, %s)',
            (room_number, capacity, 'Available')
        )
        room = _raw_query_one('SELECT RoomID FROM Room WHERE RoomNumber=%s', (room_number,))
        if room:
            _raw_execute(
                '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
                   VALUES (%s, 'CREATE', 'Room', %s, %s)''',
                (admin_id, room['RoomID'], f'Added room {room_number}')
            )
        return f'Room {room_number} added successfully.'
    except Exception as e:
        return f'ERROR: {str(e)}'


def db_update_room(room_id, room_number, capacity, status, admin_id):
    try:
        _raw_execute(
            'UPDATE Room SET RoomNumber=%s, Capacity=%s, RoomStatus=%s WHERE RoomID=%s',
            (room_number, capacity, status, room_id)
        )
        _raw_execute(
            '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
               VALUES (%s, 'UPDATE', 'Room', %s, %s)''',
            (admin_id, room_id, f'Updated room {room_number}')
        )
        return f'Room {room_number} updated successfully.'
    except Exception as e:
        return f'ERROR: {str(e)}'


def db_delete_room(room_id, admin_id):
    try:
        room = _raw_query_one('SELECT RoomNumber, CurrentOccupancy FROM Room WHERE RoomID=%s', (room_id,))
        if room and room['CurrentOccupancy'] > 0:
            return 'ERROR: Cannot delete a room that has students allocated to it.'
        _raw_execute('DELETE FROM Room WHERE RoomID=%s', (room_id,))
        _raw_execute(
            '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
               VALUES (%s, 'DELETE', 'Room', %s, %s)''',
            (admin_id, room_id, f'Deleted room ID {room_id}')
        )
        return 'Room deleted successfully.'
    except Exception as e:
        return f'ERROR: {str(e)}'


# ---------------------------------------------------------------------------
# Init passwords helper (called from /init-passwords route)
# ---------------------------------------------------------------------------

def db_set_password_for_email(email, pw_hash):
    _raw_execute('UPDATE User SET PasswordHash=%s WHERE Email=%s', (pw_hash, email))


def db_fix_placeholder_passwords(default_hash):
    """Set a proper hash for any user still storing PLACEHOLDER or empty string."""
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            "UPDATE User SET PasswordHash=%s "
            "WHERE PasswordHash='PLACEHOLDER' OR PasswordHash='' OR PasswordHash='namal123'",
            (default_hash,)
        )
        count = cur.rowcount
    conn.commit()
    return count


# ---------------------------------------------------------------------------
# Photo update control
# ---------------------------------------------------------------------------

def db_get_student_photo_status(student_id):
    """Returns dict with ProfilePhotoPath, LastPhotoUpdate, PhotoUpdateLocked."""
    return _raw_query_one(
        'SELECT ProfilePhotoPath, LastPhotoUpdate, PhotoUpdateLocked FROM Student WHERE StudentID=%s',
        (student_id,)
    )


def db_toggle_photo_lock(student_id, locked):
    _, outs = _call_proc_out('sp_TogglePhotoLock', (student_id, locked), 1)
    return outs[0]


def db_lock_all_photos(locked):
    """Lock or unlock photo updates for ALL active students. Returns count affected."""
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            '''UPDATE Student s
               JOIN User u ON s.StudentID = u.UserID
               SET s.PhotoUpdateLocked = %s
               WHERE u.IsActive = 1''',
            (locked,)
        )
        count = cur.rowcount
    conn.commit()
    return count


def db_update_profile_photo(student_id, phone, photo_path):
    """Update profile with photo, recording timestamp."""
    from datetime import datetime
    if phone:
        _raw_execute('UPDATE User SET Phone=%s WHERE UserID=%s', (phone, student_id))
    if photo_path:
        _raw_execute(
            'UPDATE Student SET ProfilePhotoPath=%s, LastPhotoUpdate=%s WHERE StudentID=%s',
            (photo_path, datetime.now(), student_id)
        )
    elif phone:
        pass  # phone-only update already done
    return 'Profile updated successfully.'


# ---------------------------------------------------------------------------
# Admin – student password reset
# ---------------------------------------------------------------------------

def db_admin_reset_student_password(student_id, new_hash, admin_id):
    _, outs = _call_proc_out('sp_AdminChangeStudentPassword',
                             (student_id, new_hash, admin_id), 1)
    return outs[0]


# ---------------------------------------------------------------------------
# Warden – attendance detail
# ---------------------------------------------------------------------------

def db_get_attendance_detail(days=30):
    """All attendance records with student + selfie photos for last N days."""
    return _raw_query(
        '''SELECT ar.AttendanceID, ar.StudentID, u.Name AS StudentName,
                  s.RollNumber, s.Department, s.ProfilePhotoPath,
                  ar.Date, ar.VerificationTime, ar.Status,
                  ar.VerificationMethod, ar.GPSLocation,
                  ar.SuspiciousFlag, ar.SelfiePath AS AttendanceSelfiePath
           FROM AttendanceRecord ar
           JOIN Student s ON ar.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           WHERE ar.Date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
           ORDER BY ar.Date DESC, ar.VerificationTime DESC''',
        (days,)
    )


def db_get_student_attendance_detail(student_id, days=30):
    """Single student attendance history with selfies."""
    return _raw_query(
        '''SELECT ar.AttendanceID, ar.Date, ar.VerificationTime, ar.Status,
                  ar.VerificationMethod, ar.GPSLocation, ar.SuspiciousFlag,
                  ar.SelfiePath AS AttendanceSelfiePath,
                  s.ProfilePhotoPath, u.Name AS StudentName, s.RollNumber
           FROM AttendanceRecord ar
           JOIN Student s ON ar.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           WHERE ar.StudentID = %s
             AND ar.Date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
           ORDER BY ar.Date DESC''',
        (student_id, days)
    )


def db_get_all_students_with_photo():
    """All students including photo info for warden photo-lock control."""
    return _raw_query(
        '''SELECT u.UserID, u.Name, u.Email, u.Phone, u.IsActive,
                  s.StudentID, s.RollNumber, s.Department, s.Semester,
                  s.ProfilePhotoPath, s.LastPhotoUpdate, s.PhotoUpdateLocked
           FROM User u
           JOIN Student s ON u.UserID = s.StudentID
           ORDER BY s.RollNumber'''
    )


# ---------------------------------------------------------------------------
# System Settings
# ---------------------------------------------------------------------------

def db_get_setting(key, default=None):
    row = _raw_query_one('SELECT SettingValue FROM SystemSettings WHERE SettingKey=%s', (key,))
    return row['SettingValue'] if row else default


def db_set_setting(key, value, admin_id=None):
    _raw_execute(
        '''INSERT INTO SystemSettings (SettingKey, SettingValue, UpdatedBy)
           VALUES (%s, %s, %s)
           ON DUPLICATE KEY UPDATE SettingValue=%s, UpdatedBy=%s, UpdatedAt=NOW()''',
        (key, value, admin_id, value, admin_id)
    )


def db_get_gate_pin():
    return db_get_setting('gate_pin', '654321')


def db_set_gate_pin(new_pin, admin_id):
    db_set_setting('gate_pin', new_pin, admin_id)
    _raw_execute(
        '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
           VALUES (%s, 'UPDATE', 'SystemSettings', 0, 'Gate PIN updated by admin')''',
        (admin_id,)
    )


# ---------------------------------------------------------------------------
# Attendance window settings
# ---------------------------------------------------------------------------

def db_get_attendance_window():
    start = int(db_get_setting('attendance_start_hour', 20))
    end   = int(db_get_setting('attendance_end_hour',   22))
    return start, end


# ---------------------------------------------------------------------------
# Check student on-leave status (blocks attendance marking)
# ---------------------------------------------------------------------------

def db_is_student_on_leave(student_id):
    """Returns True if student has an active leave application (not yet returned)."""
    row = _raw_query_one(
        '''SELECT COUNT(*) AS cnt FROM ExitApplication
           WHERE StudentID = %s AND IsOnLeave = 1
             AND ApprovalStatus IN ('Approved','Active')
             AND DATE(DepartureTime) <= CURDATE()
             AND (ExpectedReturnTime IS NULL OR ActualReturn IS NULL)''',
        (student_id,)
    )
    # simpler fallback query
    row = _raw_query_one(
        '''SELECT COUNT(*) AS cnt
           FROM ExitApplication ea
           WHERE ea.StudentID = %s
             AND ea.IsOnLeave = 1
             AND ea.ApprovalStatus IN ('Approved','Active')
             AND DATE(ea.DepartureTime) <= CURDATE()
             AND NOT EXISTS (
                 SELECT 1 FROM EntryExitLog eel
                 WHERE eel.ApplicationID = ea.ApplicationID
                   AND eel.ActualReturnTime IS NOT NULL
             )''',
        (student_id,)
    )
    return (row['cnt'] > 0) if row else False


def db_has_active_exit_application(student_id):
    """Returns active (pending/approved/active) exit app if exists."""
    return _raw_query_one(
        '''SELECT ApplicationID, ApprovalStatus, IsOnLeave, Destination
           FROM ExitApplication
           WHERE StudentID = %s
             AND ApprovalStatus IN ('Pending','Approved','Active')
           ORDER BY SubmittedAt DESC LIMIT 1''',
        (student_id,)
    )


# ---------------------------------------------------------------------------
# Warden reports
# ---------------------------------------------------------------------------

def db_get_attendance_report(start_date, end_date):
    return _raw_query(
        '''SELECT u.Name, s.RollNumber, s.Department,
                  ar.Date, ar.Status, ar.VerificationTime, ar.VerificationMethod
           FROM AttendanceRecord ar
           JOIN Student s ON ar.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           WHERE ar.Date BETWEEN %s AND %s
           ORDER BY ar.Date DESC, u.Name''',
        (start_date, end_date)
    )


def db_get_room_report(start_date, end_date):
    return _raw_query(
        '''SELECT r.RoomNumber, r.Capacity, r.CurrentOccupancy, r.RoomStatus,
                  u.Name AS StudentName, s.RollNumber,
                  ra.AllocationDate, ra.DeallocationDate, ra.Status AS AllocStatus
           FROM RoomAllocation ra
           JOIN Student s ON ra.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           JOIN Room r    ON ra.RoomID    = r.RoomID
           WHERE ra.AllocationDate <= %s
             AND (ra.DeallocationDate IS NULL OR ra.DeallocationDate >= %s)
           ORDER BY r.RoomNumber, u.Name''',
        (end_date, start_date)
    )


def db_get_exit_report(start_date, end_date):
    return _raw_query(
        '''SELECT u.Name AS StudentName, s.RollNumber, ea.Destination,
                  ea.IsOnLeave, ea.DepartureTime, ea.ExpectedReturnTime,
                  ea.ApprovalStatus, eel.ExitTime, eel.ActualReturnTime, eel.LateReturnAlert
           FROM ExitApplication ea
           JOIN Student s ON ea.StudentID = s.StudentID
           JOIN User u    ON s.StudentID  = u.UserID
           LEFT JOIN EntryExitLog eel ON eel.ApplicationID = ea.ApplicationID
           WHERE DATE(ea.DepartureTime) BETWEEN %s AND %s
           ORDER BY ea.DepartureTime DESC''',
        (start_date, end_date)
    )


def db_get_student_full_detail(student_id):
    """Complete student profile for warden view."""
    return _raw_query_one(
        '''SELECT u.UserID, u.Name, u.Email, u.Phone, u.CreatedAt, u.IsActive,
                  s.RollNumber, s.Department, s.Semester, s.ProfilePhotoPath,
                  s.LastPhotoUpdate, s.PhotoUpdateLocked,
                  fn_GetCurrentRoom(s.StudentID) AS CurrentRoom,
                  fn_GetAttendancePercentage(s.StudentID,
                      DATE_SUB(CURDATE(), INTERVAL 30 DAY), CURDATE()) AS AttPct30
           FROM User u JOIN Student s ON u.UserID = s.StudentID
           WHERE s.StudentID = %s''',
        (student_id,)
    )


# ---------------------------------------------------------------------------
# Bulk settings management (Admin advanced settings panel)
# ---------------------------------------------------------------------------

def db_get_all_settings():
    """Returns all system settings as a dict {key: value}."""
    rows = _raw_query('SELECT SettingKey, SettingValue FROM SystemSettings ORDER BY SettingKey')
    return {r['SettingKey']: r['SettingValue'] for r in rows}


def db_save_settings(settings_dict, admin_id):
    """Save multiple settings at once. settings_dict = {key: value}."""
    for key, value in settings_dict.items():
        _raw_execute(
            '''INSERT INTO SystemSettings (SettingKey, SettingValue, UpdatedBy)
               VALUES (%s, %s, %s)
               ON DUPLICATE KEY UPDATE SettingValue=%s, UpdatedBy=%s, UpdatedAt=NOW()''',
            (key, value, admin_id, value, admin_id)
        )
    try:
        _raw_execute(
            '''INSERT INTO SystemChangeLog (AdminID, Action, EntityName, RecordID, Description)
               VALUES (%s, 'UPDATE', 'SystemSettings', 0, 'Admin updated system settings')''',
            (admin_id,)
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Student complaint & exit history
# ---------------------------------------------------------------------------

def db_get_student_complaints(student_id):
    """All complaints submitted by a student."""
    return _raw_query(
        '''SELECT ComplaintID, Title, Description, ComplaintType,
                  Status, SubmittedAt, ResolvedAt, WardenRemarks
           FROM Complaint
           WHERE StudentID = %s
           ORDER BY SubmittedAt DESC''',
        (student_id,)
    )


def db_get_student_exit_history(student_id, days=30):
    """Exit applications for a student in last N days."""
    return _raw_query(
        '''SELECT ea.ApplicationID, ea.Destination, ea.IsOnLeave, ea.Reason,
                  ea.DepartureTime, ea.ExpectedReturnTime, ea.ApprovalStatus,
                  ea.SubmittedAt, ea.WardenRemarks,
                  eel.ExitTime, eel.ActualReturnTime, eel.LateReturnAlert
           FROM ExitApplication ea
           LEFT JOIN EntryExitLog eel ON eel.ApplicationID = ea.ApplicationID
           WHERE ea.StudentID = %s
             AND ea.SubmittedAt >= DATE_SUB(NOW(), INTERVAL %s DAY)
           ORDER BY ea.SubmittedAt DESC''',
        (student_id, days)
    )


def db_clear_student_exit_history(student_id):
    """Student clears their own returned/rejected exit records (not active ones)."""
    _raw_execute(
        '''DELETE eel FROM EntryExitLog eel
           JOIN ExitApplication ea ON eel.ApplicationID = ea.ApplicationID
           WHERE ea.StudentID = %s
             AND ea.ApprovalStatus IN ('Returned','Rejected')''',
        (student_id,)
    )
    _raw_execute(
        '''DELETE FROM ExitApplication
           WHERE StudentID = %s
             AND ApprovalStatus IN ('Returned','Rejected')''',
        (student_id,)
    )
    return 'Exit history cleared.'
