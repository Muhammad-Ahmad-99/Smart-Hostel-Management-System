"""
generate_students_sql.py
Run: python generate_students_sql.py
Outputs: dbDML_students.sql  with all 296 female students
"""

students = [
    # (Name, Email, Dept_code, Roll)
    # BSEE 2022
    ("Kinza Khan","bsee22f05@namal.edu.pk","BSEE","NUM-BSEE-2022-05"),
    ("Fatima Tu Zahra","bsee22f06@namal.edu.pk","BSEE","NUM-BSEE-2022-06"),
    ("Umm E Ammara","bsee22f08@namal.edu.pk","BSEE","NUM-BSEE-2022-08"),
    ("Laraib Gul","bsee22f15@namal.edu.pk","BSEE","NUM-BSEE-2022-15"),
    ("Muqadas Bibi","bsee22f18@namal.edu.pk","BSEE","NUM-BSEE-2022-18"),
    ("Sobia Batool","bsee22f19@namal.edu.pk","BSEE","NUM-BSEE-2022-19"),
    ("Mehnaz Akhtar","bsee22f29@namal.edu.pk","BSEE","NUM-BSEE-2022-29"),
    ("Shagufta Kanwal","bsee22f31@namal.edu.pk","BSEE","NUM-BSEE-2022-31"),
    ("Bushra Fatima","bsee22f32@namal.edu.pk","BSEE","NUM-BSEE-2022-32"),
    ("Noreen Arshad","bsee22f37@namal.edu.pk","BSEE","NUM-BSEE-2022-37"),
    ("Hafsa Tanveer","bsee22f42@namal.edu.pk","BSEE","NUM-BSEE-2022-42"),
    # BSEE 2023
    ("Sana Azeem","bsee23f02@namal.edu.pk","BSEE","NUM-BSEE-2023-02"),
    ("Khola Khalid","bsee23f09@namal.edu.pk","BSEE","NUM-BSEE-2023-09"),
    ("Alisha Fatima","bsee23f13@namal.edu.pk","BSEE","NUM-BSEE-2023-13"),
    ("Kinza Wajid","bsee23f15@namal.edu.pk","BSEE","NUM-BSEE-2023-15"),
    ("Wania Naeem","bsee23f30@namal.edu.pk","BSEE","NUM-BSEE-2023-30"),
    ("Aqsa Tahir","bsee23f32@namal.edu.pk","BSEE","NUM-BSEE-2023-32"),
    ("Laraib Shahid","bsee23f33@namal.edu.pk","BSEE","NUM-BSEE-2023-33"),
    # BSEE 2024
    ("Ayat UL Sabah","bsee24f06@namal.edu.pk","BSEE","NUM-BSEE-2024-06"),
    ("Faiza Saeed","bsee24f08@namal.edu.pk","BSEE","NUM-BSEE-2024-08"),
    ("iffat islam shahid","bsee24f13@namal.edu.pk","BSEE","NUM-BSEE-2024-13"),
    ("Iqra Wazeer","bsee24f14@namal.edu.pk","BSEE","NUM-BSEE-2024-14"),
    ("Javeria Naseem","bsee24f15@namal.edu.pk","BSEE","NUM-BSEE-2024-15"),
    ("Kanza Imran","bsee24f16@namal.edu.pk","BSEE","NUM-BSEE-2024-16"),
    ("Maria Iftikhar","bsee24f17@namal.edu.pk","BSEE","NUM-BSEE-2024-17"),
    ("Nimrah Hussain","bsee24f28@namal.edu.pk","BSEE","NUM-BSEE-2024-28"),
    ("Rafia","bsee24f29@namal.edu.pk","BSEE","NUM-BSEE-2024-29"),
    ("Rimsha Nadeem","bsee24f30@namal.edu.pk","BSEE","NUM-BSEE-2024-30"),
    ("Shaista","bsee24f32@namal.edu.pk","BSEE","NUM-BSEE-2024-32"),
    ("Um E Habiba","bsee24f34@namal.edu.pk","BSEE","NUM-BSEE-2024-34"),
    # BSEE 2025
    ("Ameema Adeen","bsee25f03@namal.edu.pk","BSEE","NUM-BSEE-2025-03"),
    ("Arooj Fatima","bsee25f04@namal.edu.pk","BSEE","NUM-BSEE-2025-04"),
    ("Hijab Noor","bsee25f10@namal.edu.pk","BSEE","NUM-BSEE-2025-10"),
    ("Jaweria Raheem","bsee25f13@namal.edu.pk","BSEE","NUM-BSEE-2025-13"),
    ("Kashmala Imran","bsee25f14@namal.edu.pk","BSEE","NUM-BSEE-2025-14"),
    ("Laiba Yasmeen","bsee25f15@namal.edu.pk","BSEE","NUM-BSEE-2025-15"),
    ("Maha Sajid","bsee25f17@namal.edu.pk","BSEE","NUM-BSEE-2025-17"),
    ("Maryam Noor","bsee25f19@namal.edu.pk","BSEE","NUM-BSEE-2025-19"),
    ("Samreen","bsee25f43@namal.edu.pk","BSEE","NUM-BSEE-2025-43"),
    ("Tayyaba Noor","bsee25f45@namal.edu.pk","BSEE","NUM-BSEE-2025-45"),
    ("Uswa Batool","bsee25f49@namal.edu.pk","BSEE","NUM-BSEE-2025-49"),
    ("Wareesha Hassan Malik","bsee25f51@namal.edu.pk","BSEE","NUM-BSEE-2025-51"),
    # BSCS 2022
    ("Anam Fatima","bscs22f01@namal.edu.pk","BSCS","NUM-BSCS-2022-01"),
    ("Atiqa Shaheen","bscs22f04@namal.edu.pk","BSCS","NUM-BSCS-2022-04"),
    ("Laraib Sultana","bscs22f06@namal.edu.pk","BSCS","NUM-BSCS-2022-06"),
    ("Shazia Nazir","bscs22f09@namal.edu.pk","BSCS","NUM-BSCS-2022-09"),
    ("Nasreen Bi Bi","bscs22f10@namal.edu.pk","BSCS","NUM-BSCS-2022-10"),
    ("Ayesha Tahir","bscs22f17@namal.edu.pk","BSCS","NUM-BSCS-2022-17"),
    ("Munaza Shafiq","bscs22f20@namal.edu.pk","BSCS","NUM-BSCS-2022-20"),
    ("Mehwish Sana","bscs22f22@namal.edu.pk","BSCS","NUM-BSCS-2022-22"),
    ("Mariyam Noor Ul Ain","bscs22f25@namal.edu.pk","BSCS","NUM-BSCS-2022-25"),
    ("Usaira Shahbaz Zahid","bscs22f27@namal.edu.pk","BSCS","NUM-BSCS-2022-27"),
    ("Zunaira Akbar","bscs22f34@namal.edu.pk","BSCS","NUM-BSCS-2022-34"),
    ("Shehzana Bibi","bscs22f44@namal.edu.pk","BSCS","NUM-BSCS-2022-44"),
    ("Eshna Eman","bscs22f51@namal.edu.pk","BSCS","NUM-BSCS-2022-51"),
    ("Samreen Fatima Kazmi","bscs22f52@namal.edu.pk","BSCS","NUM-BSCS-2022-52"),
    ("Saeeda Farnaz","bscs22f54@namal.edu.pk","BSCS","NUM-BSCS-2022-54"),
    # BSCS 2023
    ("Javeria Nawal","bscs23f03@namal.edu.pk","BSCS","NUM-BSCS-2023-03"),
    ("Tayyaba Noor","bscs23f04@namal.edu.pk","BSCS","NUM-BSCS-2023-04"),
    ("Anila Younas","bscs23f05@namal.edu.pk","BSCS","NUM-BSCS-2023-05"),
    ("Anam Fatima","bscs23f06@namal.edu.pk","BSCS","NUM-BSCS-2023-06"),
    ("Huzaira Sultan","bscs23f07@namal.edu.pk","BSCS","NUM-BSCS-2023-07"),
    ("Reeha Batool","bscs23f09@namal.edu.pk","BSCS","NUM-BSCS-2023-09"),
    ("Shehr Bano","bscs23f11@namal.edu.pk","BSCS","NUM-BSCS-2023-11"),
    ("Amara Bibi","bscs23f14@namal.edu.pk","BSCS","NUM-BSCS-2023-14"),
    ("Laiba Shaheen","bscs23f16@namal.edu.pk","BSCS","NUM-BSCS-2023-16"),
    ("Sawaira Tabbasum","bscs23f17@namal.edu.pk","BSCS","NUM-BSCS-2023-17"),
    ("Aqsa Aziz","bscs23f22@namal.edu.pk","BSCS","NUM-BSCS-2023-22"),
    ("Fatima Marayam","bscs23f27@namal.edu.pk","BSCS","NUM-BSCS-2023-27"),
    ("Ghazia Arshad","bscs23f32@namal.edu.pk","BSCS","NUM-BSCS-2023-32"),
    ("Sumaira Majeed","bscs23f33@namal.edu.pk","BSCS","NUM-BSCS-2023-33"),
    ("Iqra Gul","bscs23f35@namal.edu.pk","BSCS","NUM-BSCS-2023-35"),
    # BSCS 2024
    ("Aleesha Zulifqar","bscs24f05@namal.edu.pk","BSCS","NUM-BSCS-2024-05"),
    ("Alina Tawakkal","bscs24f07@namal.edu.pk","BSCS","NUM-BSCS-2024-07"),
    ("Aliya Ashraf","bscs24f08@namal.edu.pk","BSCS","NUM-BSCS-2024-08"),
    ("Aliza Bashir","bscs24f09@namal.edu.pk","BSCS","NUM-BSCS-2024-09"),
    ("Ammara Ahmar","bscs24f12@namal.edu.pk","BSCS","NUM-BSCS-2024-12"),
    ("Amna Ahsan","bscs24f13@namal.edu.pk","BSCS","NUM-BSCS-2024-13"),
    ("Amra Riaz","bscs24f14@namal.edu.pk","BSCS","NUM-BSCS-2024-14"),
    ("Areeba Tahir","bscs24f15@namal.edu.pk","BSCS","NUM-BSCS-2024-15"),
    ("Arfa Tayyabah","bscs24f16@namal.edu.pk","BSCS","NUM-BSCS-2024-16"),
    ("Bareera Ijaz","bscs24f20@namal.edu.pk","BSCS","NUM-BSCS-2024-20"),
    ("Farwa Imran","bscs24f22@namal.edu.pk","BSCS","NUM-BSCS-2024-22"),
    ("Hadia Yasir","bscs24f23@namal.edu.pk","BSCS","NUM-BSCS-2024-23"),
    ("Hafsa Gul","bscs24f24@namal.edu.pk","BSCS","NUM-BSCS-2024-24"),
    ("Hifza Bibi","bscs24f27@namal.edu.pk","BSCS","NUM-BSCS-2024-27"),
    ("Khadija Tul Kubra","bscs24f30@namal.edu.pk","BSCS","NUM-BSCS-2024-30"),
    ("Laiba Taj","bscs24f31@namal.edu.pk","BSCS","NUM-BSCS-2024-31"),
    ("Maryam Rashid","bscs24f33@namal.edu.pk","BSCS","NUM-BSCS-2024-33"),
    ("Momina Umer","bscs24f36@namal.edu.pk","BSCS","NUM-BSCS-2024-36"),
    ("Najeeba","bscs24f61@namal.edu.pk","BSCS","NUM-BSCS-2024-61"),
    ("Najia Nayab","bscs24f62@namal.edu.pk","BSCS","NUM-BSCS-2024-62"),
    ("Rabia Ashraf","bscs24f65@namal.edu.pk","BSCS","NUM-BSCS-2024-65"),
    ("Sadia","bscs24f68@namal.edu.pk","BSCS","NUM-BSCS-2024-68"),
    ("Sadia Rahmeen","bscs24f69@namal.edu.pk","BSCS","NUM-BSCS-2024-69"),
    ("Samia Waris","bscs24f71@namal.edu.pk","BSCS","NUM-BSCS-2024-71"),
    ("Shumaila Sarfraz","bscs24f74@namal.edu.pk","BSCS","NUM-BSCS-2024-74"),
    ("Tahira Hanif","bscs24f76@namal.edu.pk","BSCS","NUM-BSCS-2024-76"),
    ("Zainab Bibi","bscs24f79@namal.edu.pk","BSCS","NUM-BSCS-2024-79"),
    # BSCS 2025
    ("Alishba Sana","bscs25f04@namal.edu.pk","BSCS","NUM-BSCS-2025-04"),
    ("Aliza Fatima","bscs25f05@namal.edu.pk","BSCS","NUM-BSCS-2025-05"),
    ("Amna Bibi","bscs25f07@namal.edu.pk","BSCS","NUM-BSCS-2025-07"),
    ("Amna Khadim","bscs25f08@namal.edu.pk","BSCS","NUM-BSCS-2025-08"),
    ("Anaya Nawal","bscs25f10@namal.edu.pk","BSCS","NUM-BSCS-2025-10"),
    ("Ayesha Parveen","bscs25f13@namal.edu.pk","BSCS","NUM-BSCS-2025-13"),
    ("Dua","bscs25f14@namal.edu.pk","BSCS","NUM-BSCS-2025-14"),
    ("Hafsa Munawar","bscs25f15@namal.edu.pk","BSCS","NUM-BSCS-2025-15"),
    ("Hania Nawab","bscs25f17@namal.edu.pk","BSCS","NUM-BSCS-2025-17"),
    ("Huma Aslam","bscs25f20@namal.edu.pk","BSCS","NUM-BSCS-2025-20"),
    ("Iqra Bibi","bscs25f21@namal.edu.pk","BSCS","NUM-BSCS-2025-21"),
    ("Laiba Hussain","bscs25f23@namal.edu.pk","BSCS","NUM-BSCS-2025-23"),
    ("Madiha Akram","bscs25f24@namal.edu.pk","BSCS","NUM-BSCS-2025-24"),
    ("Maham","bscs25f25@namal.edu.pk","BSCS","NUM-BSCS-2025-25"),
    ("Mehreen Fatima","bscs25f26@namal.edu.pk","BSCS","NUM-BSCS-2025-26"),
    ("Mehwish Eman","bscs25f27@namal.edu.pk","BSCS","NUM-BSCS-2025-27"),
    ("Munaza Bibi","bscs25f44@namal.edu.pk","BSCS","NUM-BSCS-2025-44"),
    ("Rabia Irshad Hashmi","bscs25f46@namal.edu.pk","BSCS","NUM-BSCS-2025-46"),
    ("Raheela Aziz","bscs25f47@namal.edu.pk","BSCS","NUM-BSCS-2025-47"),
    ("Romaisa Maryam","bscs25f48@namal.edu.pk","BSCS","NUM-BSCS-2025-48"),
    ("Sadaf","bscs25f49@namal.edu.pk","BSCS","NUM-BSCS-2025-49"),
    ("Sania Fatima","bscs25f51@namal.edu.pk","BSCS","NUM-BSCS-2025-51"),
    ("Sehrish Shafiq","bscs25f52@namal.edu.pk","BSCS","NUM-BSCS-2025-52"),
    ("Shumaila Nawaz","bscs25f53@namal.edu.pk","BSCS","NUM-BSCS-2025-53"),
    ("Sobia Madad Ali","bscs25f54@namal.edu.pk","BSCS","NUM-BSCS-2025-54"),
    ("Sobia Nosheen","bscs25f55@namal.edu.pk","BSCS","NUM-BSCS-2025-55"),
    ("Tayyaba Akhtar","bscs25f59@namal.edu.pk","BSCS","NUM-BSCS-2025-59"),
    ("Laiba Zafar Khan","bscs25f61@namal.edu.pk","BSCS","NUM-BSCS-2025-61"),
    # BBA 2022
    ("Rabbia Hameed","bba22f02@namal.edu.pk","BBA","NUM-BBA-2022-02"),
    ("Qurrat","bba22f04@namal.edu.pk","BBA","NUM-BBA-2022-04"),
    ("Fazeelat","bba22f05@namal.edu.pk","BBA","NUM-BBA-2022-05"),
    ("Fariha Jabeen","bba22f07@namal.edu.pk","BBA","NUM-BBA-2022-07"),
    ("Laraib Akhtar","bba22f09@namal.edu.pk","BBA","NUM-BBA-2022-09"),
    ("Zoya Rubbab","bba22f14@namal.edu.pk","BBA","NUM-BBA-2022-14"),
    ("Zainab Urooj","bba22f20@namal.edu.pk","BBA","NUM-BBA-2022-20"),
    ("Fatima Tariq","bba22f22@namal.edu.pk","BBA","NUM-BBA-2022-22"),
    ("Ayesha Sana","bba22f24@namal.edu.pk","BBA","NUM-BBA-2022-24"),
    ("Maham Aleem","bba22f27@namal.edu.pk","BBA","NUM-BBA-2022-27"),
    ("Iqra Fatima","bba22f29@namal.edu.pk","BBA","NUM-BBA-2022-29"),
    ("Eman Zafar","bba22f30@namal.edu.pk","BBA","NUM-BBA-2022-30"),
    ("Areeba Fatima","bba22f33@namal.edu.pk","BBA","NUM-BBA-2022-33"),
    # BBA 2023
    ("Raheela Bibi","bba23f03@namal.edu.pk","BBA","NUM-BBA-2023-03"),
    ("Syeda Aman Hamdani","bba23f04@namal.edu.pk","BBA","NUM-BBA-2023-04"),
    ("Kinza Malik","bba23f05@namal.edu.pk","BBA","NUM-BBA-2023-05"),
    ("Rabia Bashir","bba23f07@namal.edu.pk","BBA","NUM-BBA-2023-07"),
    ("Zoya Ambreen","bba23f08@namal.edu.pk","BBA","NUM-BBA-2023-08"),
    ("Salma Bano","bba23f09@namal.edu.pk","BBA","NUM-BBA-2023-09"),
    ("Zahra Mazari","bba23f11@namal.edu.pk","BBA","NUM-BBA-2023-11"),
    ("Syeda Rabail Hamdani","bba23f12@namal.edu.pk","BBA","NUM-BBA-2023-12"),
    ("Ayesha Ahmad","bba23f13@namal.edu.pk","BBA","NUM-BBA-2023-13"),
    ("Arifa Bibi","bba23f14@namal.edu.pk","BBA","NUM-BBA-2023-14"),
    ("Uswa Asif","bba23f17@namal.edu.pk","BBA","NUM-BBA-2023-17"),
    ("Muqdis Bibi","bba23f19@namal.edu.pk","BBA","NUM-BBA-2023-19"),
    ("Alishba Samreen","bba23f20@namal.edu.pk","BBA","NUM-BBA-2023-20"),
    ("Noor Fatima","bba23f22@namal.edu.pk","BBA","NUM-BBA-2023-22"),
    ("Ujala Aslam","bba23f24@namal.edu.pk","BBA","NUM-BBA-2023-24"),
    ("Ayesha Ramzan","bba23f26@namal.edu.pk","BBA","NUM-BBA-2023-26"),
    ("Huma Latif","bba23f28@namal.edu.pk","BBA","NUM-BBA-2023-28"),
    ("Robina Tariq","bba23f29@namal.edu.pk","BBA","NUM-BBA-2023-29"),
    ("Sidra Saleem","bba23f32@namal.edu.pk","BBA","NUM-BBA-2023-32"),
    ("Hira Naeem","bba23f37@namal.edu.pk","BBA","NUM-BBA-2023-37"),
    ("Iqra Tariq","bba23f41@namal.edu.pk","BBA","NUM-BBA-2023-41"),
    ("Aqsa Abid","bba23f42@namal.edu.pk","BBA","NUM-BBA-2023-42"),
    ("Munaza Batool","bba23f43@namal.edu.pk","BBA","NUM-BBA-2023-43"),
    ("Aqsa Bibi","bba23f44@namal.edu.pk","BBA","NUM-BBA-2023-44"),
    ("Humaira Khan","bba23f48@namal.edu.pk","BBA","NUM-BBA-2023-48"),
    # BBA 2024
    ("Alishba Arshad","bba24f06@namal.edu.pk","BBA","NUM-BBA-2024-06"),
    ("Alishba Rafique","bba24f07@namal.edu.pk","BBA","NUM-BBA-2024-07"),
    ("Amra Imran","bba24f08@namal.edu.pk","BBA","NUM-BBA-2024-08"),
    ("Ayesha Abubakar","bba24f09@namal.edu.pk","BBA","NUM-BBA-2024-09"),
    ("Ayesha Khalid","bba24f10@namal.edu.pk","BBA","NUM-BBA-2024-10"),
    ("Batool Fatima","bba24f11@namal.edu.pk","BBA","NUM-BBA-2024-11"),
    ("Fatima Khan","bba24f14@namal.edu.pk","BBA","NUM-BBA-2024-14"),
    ("Fiza Fatima","bba24f15@namal.edu.pk","BBA","NUM-BBA-2024-15"),
    ("Hadia Batool","bba24f18@namal.edu.pk","BBA","NUM-BBA-2024-18"),
    ("Hamna Khan","bba24f19@namal.edu.pk","BBA","NUM-BBA-2024-19"),
    ("Hanan Yaseen","bba24f20@namal.edu.pk","BBA","NUM-BBA-2024-20"),
    ("Ishrat Fatima","bba24f22@namal.edu.pk","BBA","NUM-BBA-2024-22"),
    ("Malaika Saeed","bba24f23@namal.edu.pk","BBA","NUM-BBA-2024-23"),
    ("Maria","bba24f24@namal.edu.pk","BBA","NUM-BBA-2024-24"),
    ("Maria Ashraf","bba24f25@namal.edu.pk","BBA","NUM-BBA-2024-25"),
    ("Maryam Noor","bba24f26@namal.edu.pk","BBA","NUM-BBA-2024-26"),
    ("Meerab Asghar","bba24f27@namal.edu.pk","BBA","NUM-BBA-2024-27"),
    ("Mehwish Irfan","bba24f28@namal.edu.pk","BBA","NUM-BBA-2024-28"),
    ("Muskan Bibi","bba24f39@namal.edu.pk","BBA","NUM-BBA-2024-39"),
    ("Nimra Niazi","bba24f41@namal.edu.pk","BBA","NUM-BBA-2024-41"),
    ("Ruqia Aziz","bba24f46@namal.edu.pk","BBA","NUM-BBA-2024-46"),
    ("Saba Noor Fatima","bba24f47@namal.edu.pk","BBA","NUM-BBA-2024-47"),
    ("Sadia Siddique","bba24f48@namal.edu.pk","BBA","NUM-BBA-2024-48"),
    ("Saher Fatima","bba24f49@namal.edu.pk","BBA","NUM-BBA-2024-49"),
    ("Samreen Zahid","bba24f51@namal.edu.pk","BBA","NUM-BBA-2024-51"),
    ("Sawaira Khan","bba24f52@namal.edu.pk","BBA","NUM-BBA-2024-52"),
    ("Shiza","bba24f53@namal.edu.pk","BBA","NUM-BBA-2024-53"),
    ("Shumaila Bibi","bba24f54@namal.edu.pk","BBA","NUM-BBA-2024-54"),
    ("Sidra Tul Muntha","bba24f55@namal.edu.pk","BBA","NUM-BBA-2024-55"),
    ("Summayya Rana","bba24f57@namal.edu.pk","BBA","NUM-BBA-2024-57"),
    ("Tanzila Younas","bba24f58@namal.edu.pk","BBA","NUM-BBA-2024-58"),
    ("Tayyaba Naz","bba24f59@namal.edu.pk","BBA","NUM-BBA-2024-59"),
    ("Zounaisha Batool","bba24f62@namal.edu.pk","BBA","NUM-BBA-2024-62"),
    # BBA 2025
    ("Aneesa Mushtaq","bba25f05@namal.edu.pk","BBA","NUM-BBA-2025-05"),
    ("Ayesha","bba25f07@namal.edu.pk","BBA","NUM-BBA-2025-07"),
    ("Fatima Tu Zahra","bba25f09@namal.edu.pk","BBA","NUM-BBA-2025-09"),
    ("Hamna Farooq","bba25f11@namal.edu.pk","BBA","NUM-BBA-2025-11"),
    ("Hifza Bibi","bba25f12@namal.edu.pk","BBA","NUM-BBA-2025-12"),
    ("Hifza Mehmood","bba25f13@namal.edu.pk","BBA","NUM-BBA-2025-13"),
    ("Hira Mumtaz","bba25f14@namal.edu.pk","BBA","NUM-BBA-2025-14"),
    ("Iqra","bba25f15@namal.edu.pk","BBA","NUM-BBA-2025-15"),
    ("Khadija Raheel","bba25f16@namal.edu.pk","BBA","NUM-BBA-2025-16"),
    ("Khadijah Imran","bba25f17@namal.edu.pk","BBA","NUM-BBA-2025-17"),
    ("Khansa Khushbakht","bba25f18@namal.edu.pk","BBA","NUM-BBA-2025-18"),
    ("Kinza Tasswar","bba25f19@namal.edu.pk","BBA","NUM-BBA-2025-19"),
    ("Laraib Ajmal","bba25f20@namal.edu.pk","BBA","NUM-BBA-2025-20"),
    ("Maira Sajid","bba25f22@namal.edu.pk","BBA","NUM-BBA-2025-22"),
    ("Mariam Sardar","bba25f23@namal.edu.pk","BBA","NUM-BBA-2025-23"),
    ("Maryam","bba25f24@namal.edu.pk","BBA","NUM-BBA-2025-24"),
    ("Maryam","bba25f25@namal.edu.pk","BBA","NUM-BBA-2025-25"),
    ("Maryam Fatima","bba25f26@namal.edu.pk","BBA","NUM-BBA-2025-26"),
    ("Munazza Hameed","bba25f36@namal.edu.pk","BBA","NUM-BBA-2025-36"),
    ("Musfira Fatima","bba25f38@namal.edu.pk","BBA","NUM-BBA-2025-38"),
    ("Nafeesa Khatoon","bba25f39@namal.edu.pk","BBA","NUM-BBA-2025-39"),
    ("Rafia Bibi","bba25f40@namal.edu.pk","BBA","NUM-BBA-2025-40"),
    ("Resham Sadia","bba25f42@namal.edu.pk","BBA","NUM-BBA-2025-42"),
    ("Sadaf Gull","bba25f44@namal.edu.pk","BBA","NUM-BBA-2025-44"),
    ("Safia Bilal","bba25f45@namal.edu.pk","BBA","NUM-BBA-2025-45"),
    ("Sania Naseer","bba25f47@namal.edu.pk","BBA","NUM-BBA-2025-47"),
    ("Sania Nawab","bba25f48@namal.edu.pk","BBA","NUM-BBA-2025-48"),
    ("Sawera Malik","bba25f49@namal.edu.pk","BBA","NUM-BBA-2025-49"),
    ("Simra Adeen","bba25f50@namal.edu.pk","BBA","NUM-BBA-2025-50"),
    ("Sundas Abdullah","bba25f51@namal.edu.pk","BBA","NUM-BBA-2025-51"),
    ("Tehreem Fatima","bba25f52@namal.edu.pk","BBA","NUM-BBA-2025-52"),
    ("Umaima Maryam","bba25f53@namal.edu.pk","BBA","NUM-BBA-2025-53"),
    ("Umama Akram","bba25f54@namal.edu.pk","BBA","NUM-BBA-2025-54"),
    ("Ummul Baneen Zahra","bba25f55@namal.edu.pk","BBA","NUM-BBA-2025-55"),
    ("Urooj Fatima","bba25f56@namal.edu.pk","BBA","NUM-BBA-2025-56"),
    ("Zainab Hayat","bba25f57@namal.edu.pk","BBA","NUM-BBA-2025-57"),
    ("Zakia Faiz","bba25f58@namal.edu.pk","BBA","NUM-BBA-2025-58"),
    # BSMTH 2022
    ("Hafza Batool","bsmth22f01@namal.edu.pk","BSMTH","NUM-BSMTH-2022-01"),
    ("Mariam Bibi","bsmth22f02@namal.edu.pk","BSMTH","NUM-BSMTH-2022-02"),
    ("Arfa Tehreem","bsmth22f04@namal.edu.pk","BSMTH","NUM-BSMTH-2022-04"),
    ("Laraib Malik","bsmth22f06@namal.edu.pk","BSMTH","NUM-BSMTH-2022-06"),
    ("Farzana Bashir","bsmth22f08@namal.edu.pk","BSMTH","NUM-BSMTH-2022-08"),
    ("Sobia Khan","bsmth22f10@namal.edu.pk","BSMTH","NUM-BSMTH-2022-10"),
    ("Sadia Saif","bsmth22f15@namal.edu.pk","BSMTH","NUM-BSMTH-2022-15"),
    ("Areeba Fatima","bsmth22f16@namal.edu.pk","BSMTH","NUM-BSMTH-2022-16"),
    ("Manahil Khan","bsmth22f17@namal.edu.pk","BSMTH","NUM-BSMTH-2022-17"),
    ("Rehana Murtaza","bsmth22f18@namal.edu.pk","BSMTH","NUM-BSMTH-2022-18"),
    ("Alishba Khan","bsmth22f20@namal.edu.pk","BSMTH","NUM-BSMTH-2022-20"),
    ("Malaika Ayub","bsmth22f23@namal.edu.pk","BSMTH","NUM-BSMTH-2022-23"),
    ("Mishal Fatima","bsmth22f26@namal.edu.pk","BSMTH","NUM-BSMTH-2022-26"),
    ("Muskan Fatima","bsmth22f27@namal.edu.pk","BSMTH","NUM-BSMTH-2022-27"),
    ("Muneeba Shakeel","bsmth22f28@namal.edu.pk","BSMTH","NUM-BSMTH-2022-28"),
    ("Muniba Iftikhar","bsmth22f31@namal.edu.pk","BSMTH","NUM-BSMTH-2022-31"),
    ("Tanveez Begum","bsmth22f33@namal.edu.pk","BSMTH","NUM-BSMTH-2022-33"),
    ("Alishba Khalid","bsmth22f34@namal.edu.pk","BSMTH","NUM-BSMTH-2022-34"),
    ("Mehwish Noreen","bsmth22f35@namal.edu.pk","BSMTH","NUM-BSMTH-2022-35"),
    ("Irum Fatima","bsmth22f37@namal.edu.pk","BSMTH","NUM-BSMTH-2022-37"),
    ("Sara Qaisar","bsmth22f38@namal.edu.pk","BSMTH","NUM-BSMTH-2022-38"),
    ("Sidra Hayat","bsmth22f43@namal.edu.pk","BSMTH","NUM-BSMTH-2022-43"),
    # BSMTH 2023
    ("Kinza Iqbal","bsmth23f02@namal.edu.pk","BSMTH","NUM-BSMTH-2023-02"),
    ("Aqsa Sadique","bsmth23f03@namal.edu.pk","BSMTH","NUM-BSMTH-2023-03"),
    ("Rimsha Munawar","bsmth23f04@namal.edu.pk","BSMTH","NUM-BSMTH-2023-04"),
    ("Minahil Tahir","bsmth23f05@namal.edu.pk","BSMTH","NUM-BSMTH-2023-05"),
    ("Nadia Amber","bsmth23f06@namal.edu.pk","BSMTH","NUM-BSMTH-2023-06"),
    ("Saleha Ahmed","bsmth23f07@namal.edu.pk","BSMTH","NUM-BSMTH-2023-07"),
    ("Rehana Haider","bsmth23f08@namal.edu.pk","BSMTH","NUM-BSMTH-2023-08"),
    ("Sawaira Kanwal","bsmth23f09@namal.edu.pk","BSMTH","NUM-BSMTH-2023-09"),
    ("Aniqa Esha","bsmth23f10@namal.edu.pk","BSMTH","NUM-BSMTH-2023-10"),
    ("Madiha Fatima","bsmth23f11@namal.edu.pk","BSMTH","NUM-BSMTH-2023-11"),
    ("Hadia Gul","bsmth23f12@namal.edu.pk","BSMTH","NUM-BSMTH-2023-12"),
    ("Aiman Fatima","bsmth23f13@namal.edu.pk","BSMTH","NUM-BSMTH-2023-13"),
    ("Tasmia Fatima","bsmth23f14@namal.edu.pk","BSMTH","NUM-BSMTH-2023-14"),
    ("Aliya Yasmeen","bsmth23f16@namal.edu.pk","BSMTH","NUM-BSMTH-2023-16"),
    ("Aqsa Bibi","bsmth23f17@namal.edu.pk","BSMTH","NUM-BSMTH-2023-17"),
    ("Rozeena Kanwal","bsmth23f20@namal.edu.pk","BSMTH","NUM-BSMTH-2023-20"),
    ("Muskan Gul","bsmth23f21@namal.edu.pk","BSMTH","NUM-BSMTH-2023-21"),
    ("Qura Tul Ain","bsmth23f22@namal.edu.pk","BSMTH","NUM-BSMTH-2023-22"),
    ("Bushra Ashraf","bsmth23f23@namal.edu.pk","BSMTH","NUM-BSMTH-2023-23"),
    ("Nazish Rizwan","bsmth23f26@namal.edu.pk","BSMTH","NUM-BSMTH-2023-26"),
    # BSMTH 2024
    ("Aiman Fatima","bsmth24f02@namal.edu.pk","BSMTH","NUM-BSMTH-2024-02"),
    ("Aleeza Shehzadi","bsmth24f04@namal.edu.pk","BSMTH","NUM-BSMTH-2024-04"),
    ("Alishba Faisal","bsmth24f05@namal.edu.pk","BSMTH","NUM-BSMTH-2024-05"),
    ("Alishba Shoukat","bsmth24f06@namal.edu.pk","BSMTH","NUM-BSMTH-2024-06"),
    ("Amna","bsmth24f07@namal.edu.pk","BSMTH","NUM-BSMTH-2024-07"),
    ("Asma Fatima","bsmth24f09@namal.edu.pk","BSMTH","NUM-BSMTH-2024-09"),
    ("Faryal Fatima","bsmth24f10@namal.edu.pk","BSMTH","NUM-BSMTH-2024-10"),
    ("Fatima Bibi","bsmth24f11@namal.edu.pk","BSMTH","NUM-BSMTH-2024-11"),
    ("Hafsa Laraib","bsmth24f12@namal.edu.pk","BSMTH","NUM-BSMTH-2024-12"),
    ("Hajra Bibi","bsmth24f13@namal.edu.pk","BSMTH","NUM-BSMTH-2024-13"),
    ("Hareem Ul Taqaddus","bsmth24f14@namal.edu.pk","BSMTH","NUM-BSMTH-2024-14"),
    ("Kashaf Gul","bsmth24f16@namal.edu.pk","BSMTH","NUM-BSMTH-2024-16"),
    ("Laiba Bibi","bsmth24f17@namal.edu.pk","BSMTH","NUM-BSMTH-2024-17"),
    ("Maryam Javed","bsmth24f18@namal.edu.pk","BSMTH","NUM-BSMTH-2024-18"),
    ("Mehak Yousaf","bsmth24f19@namal.edu.pk","BSMTH","NUM-BSMTH-2024-19"),
    ("Mehwish Bibi","bsmth24f20@namal.edu.pk","BSMTH","NUM-BSMTH-2024-20"),
    ("Rabia Noreen","bsmth24f26@namal.edu.pk","BSMTH","NUM-BSMTH-2024-26"),
    ("Samra","bsmth24f28@namal.edu.pk","BSMTH","NUM-BSMTH-2024-28"),
    ("Sana Iqbal","bsmth24f29@namal.edu.pk","BSMTH","NUM-BSMTH-2024-29"),
    ("Sania Sundas","bsmth24f30@namal.edu.pk","BSMTH","NUM-BSMTH-2024-30"),
    ("Shakeela Batool","bsmth24f32@namal.edu.pk","BSMTH","NUM-BSMTH-2024-32"),
    ("Shiza Bibi","bsmth24f33@namal.edu.pk","BSMTH","NUM-BSMTH-2024-33"),
    ("Sobia Tariq","bsmth24f34@namal.edu.pk","BSMTH","NUM-BSMTH-2024-34"),
    ("Tasmia Fatima","bsmth24f35@namal.edu.pk","BSMTH","NUM-BSMTH-2024-35"),
    ("Tooba","bsmth24f37@namal.edu.pk","BSMTH","NUM-BSMTH-2024-37"),
    ("Warda Ahmad","bsmth24f38@namal.edu.pk","BSMTH","NUM-BSMTH-2024-38"),
    # BSMTH 2025
    ("Alishba Shahid","bsmth25f03@namal.edu.pk","BSMTH","NUM-BSMTH-2025-03"),
    ("Amna Bibi","bsmth25f04@namal.edu.pk","BSMTH","NUM-BSMTH-2025-04"),
    ("Areeba Javed","bsmth25f05@namal.edu.pk","BSMTH","NUM-BSMTH-2025-05"),
    ("Areej Khan","bsmth25f06@namal.edu.pk","BSMTH","NUM-BSMTH-2025-06"),
    ("Arooj Fatima","bsmth25f07@namal.edu.pk","BSMTH","NUM-BSMTH-2025-07"),
    ("Ayesha Abid","bsmth25f08@namal.edu.pk","BSMTH","NUM-BSMTH-2025-08"),
    ("Ayesha Ali","bsmth25f09@namal.edu.pk","BSMTH","NUM-BSMTH-2025-09"),
    ("Ayesha Batool","bsmth25f10@namal.edu.pk","BSMTH","NUM-BSMTH-2025-10"),
    ("Bisma Munir","bsmth25f11@namal.edu.pk","BSMTH","NUM-BSMTH-2025-11"),
    ("Eman Fatima","bsmth25f12@namal.edu.pk","BSMTH","NUM-BSMTH-2025-12"),
    ("Farzana Bibi","bsmth25f13@namal.edu.pk","BSMTH","NUM-BSMTH-2025-13"),
    ("Fatima Ghafoor","bsmth25f14@namal.edu.pk","BSMTH","NUM-BSMTH-2025-14"),
    ("Haram Fatima","bsmth25f16@namal.edu.pk","BSMTH","NUM-BSMTH-2025-16"),
    ("Hifza Iman","bsmth25f17@namal.edu.pk","BSMTH","NUM-BSMTH-2025-17"),
    ("Iraj Naheed","bsmth25f20@namal.edu.pk","BSMTH","NUM-BSMTH-2025-20"),
    ("Jasia Rehman","bsmth25f21@namal.edu.pk","BSMTH","NUM-BSMTH-2025-21"),
    ("Laiba","bsmth25f22@namal.edu.pk","BSMTH","NUM-BSMTH-2025-22"),
    ("Maira Nasir","bsmth25f23@namal.edu.pk","BSMTH","NUM-BSMTH-2025-23"),
    ("Maria Batool","bsmth25f24@namal.edu.pk","BSMTH","NUM-BSMTH-2025-24"),
    ("Misbah Parveen","bsmth25f25@namal.edu.pk","BSMTH","NUM-BSMTH-2025-25"),
    ("Naheed Fatima","bsmth25f28@namal.edu.pk","BSMTH","NUM-BSMTH-2025-28"),
    ("Rameen Naz","bsmth25f29@namal.edu.pk","BSMTH","NUM-BSMTH-2025-29"),
    ("Rehana Wazeer","bsmth25f30@namal.edu.pk","BSMTH","NUM-BSMTH-2025-30"),
    ("Rimsha Kainat","bsmth25f31@namal.edu.pk","BSMTH","NUM-BSMTH-2025-31"),
    ("Safia Bibi","bsmth25f32@namal.edu.pk","BSMTH","NUM-BSMTH-2025-32"),
    ("Samra Noor","bsmth25f33@namal.edu.pk","BSMTH","NUM-BSMTH-2025-33"),
    ("Sania Bibi","bsmth25f34@namal.edu.pk","BSMTH","NUM-BSMTH-2025-34"),
    ("Sayeda Ammara Kazmi","bsmth25f35@namal.edu.pk","BSMTH","NUM-BSMTH-2025-35"),
    ("Shua Batool","bsmth25f36@namal.edu.pk","BSMTH","NUM-BSMTH-2025-36"),
    ("Shumaila Bibi","bsmth25f37@namal.edu.pk","BSMTH","NUM-BSMTH-2025-37"),
    ("Wajeeha Nasir","bsmth25f38@namal.edu.pk","BSMTH","NUM-BSMTH-2025-38"),
    ("Zainab Yousaf","bsmth25f40@namal.edu.pk","BSMTH","NUM-BSMTH-2025-40"),
]

DEPT_MAP = {
    "BSCS":  "Computer Science",
    "BBA":   "Business Administration",
    "BSEE":  "Electrical Engineering",
    "BSMTH": "Mathematics",
}

def get_semester(email):
    # Extract year from email prefix e.g. bscs24f16 -> 24 -> 2024
    import re
    m = re.search(r'[a-z]+(\d{2})[fm]\d+', email)
    if m:
        yr = int(m.group(1))
        if yr == 22: return 8
        if yr == 23: return 6
        if yr == 24: return 4
        if yr == 25: return 2
    return 2

lines_user   = []
lines_stud   = []

for name, email, dept_code, roll in students:
    dept    = DEPT_MAP.get(dept_code, dept_code)
    sem     = get_semester(email)
    safe    = name.replace("'", "\\'")
    lines_user.append(
        f"INSERT IGNORE INTO User (Name,Email,PasswordHash,Phone,Role) VALUES "
        f"('{safe}','{email}','PLACEHOLDER','0300-1234567','Student');"
    )
    lines_stud.append(
        f"INSERT IGNORE INTO Student (StudentID,RollNumber,Department,Semester) "
        f"SELECT u.UserID,'{roll}','{dept}',{sem} FROM User u "
        f"WHERE u.Email='{email}' AND NOT EXISTS "
        f"(SELECT 1 FROM Student s WHERE s.StudentID=u.UserID);"
    )

header = """-- ============================================================
-- SHMS – Real Female Students  (296 students, Spring 2026)
-- Password: PLACEHOLDER  ->  run GET /init-passwords after import
-- Semester: 2022=8th  2023=6th  2024=4th  2025=2nd
-- ============================================================
USE shms;
SET FOREIGN_KEY_CHECKS = 0;
"""
footer = """
SET FOREIGN_KEY_CHECKS = 1;
-- ============================================================
-- After running this file, visit:
--   http://127.0.0.1:5000/init-passwords
-- to hash all PLACEHOLDER passwords to namal123
-- ============================================================
"""

output = header
output += "\n-- ── User records ───────────────────────────────────────\n"
output += "\n".join(lines_user)
output += "\n\n-- ── Student sub-records ────────────────────────────────\n"
output += "\n".join(lines_stud)
output += footer

with open("dbDML_students.sql", "w", encoding="utf-8") as f:
    f.write(output)

print(f"Generated {len(students)} students.")
print("Output: dbDML_students.sql")
print("Run: mysql -u root -p shms < dbDML_students.sql")
print("Then visit: http://127.0.0.1:5000/init-passwords")
