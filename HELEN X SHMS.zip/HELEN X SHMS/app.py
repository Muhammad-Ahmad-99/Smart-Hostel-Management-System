"""
app.py – Flask application for Smart Hostel Management System (SHMS)
Girls Hostel – Namal University
"""

import os, io, csv, base64, uuid
from datetime import datetime, timedelta, date
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, jsonify, g, Response)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

import database as db

# ---------------------------------------------------------------------------
# App config
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'shms-namal-girls-2024')
app.permanent_session_lifetime = timedelta(minutes=30)

app.config.update(
    MYSQL_HOST         = os.environ.get('MYSQLHOST',     os.environ.get('MYSQL_HOST',     'localhost')),
    MYSQL_PORT         = int(os.environ.get('MYSQLPORT', os.environ.get('MYSQL_PORT',     3306))),
    MYSQL_USER         = os.environ.get('MYSQLUSER',     os.environ.get('MYSQL_USER',     'root')),
    MYSQL_PASSWORD     = os.environ.get('MYSQLPASSWORD', os.environ.get('MYSQL_PASSWORD', 'helenhelen')),
    MYSQL_DB           = os.environ.get('MYSQLDATABASE', os.environ.get('MYSQL_DB',       'shms')),
    UPLOAD_FOLDER      = os.path.join(os.path.dirname(__file__), 'static', 'uploads'),
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024,
)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
ALLOWED_CSV        = {'csv'}
TEMP_PASSWORD      = 'namal123'
PHOTO_COOLDOWN_DAYS = 15

# Gate PIN lockout tracking (in-memory, resets on server restart)
# Structure: {'attempts': int, 'locked_until': datetime or None}
_gate_pin_state = {'attempts': 0, 'locked_until': None}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


@app.teardown_appcontext
def teardown_db(e=None):
    db.close_db(e)

# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------
def login_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if 'user_id' not in session:
            flash('Please login to continue.', 'warning')
            return redirect(url_for('login'))
        return f(*a, **kw)
    return dec

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def dec(*a, **kw):
            if 'user_id' not in session:
                flash('Please login to continue.', 'warning')
                return redirect(url_for('login'))
            if session.get('role') not in roles:
                flash('Access denied.', 'danger')
                return redirect(url_for('login'))
            return f(*a, **kw)
        return dec
    return decorator

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def allowed_file(fn):
    return '.' in fn and fn.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def allowed_csv(fn):
    return '.' in fn and fn.rsplit('.', 1)[1].lower() in ALLOWED_CSV

def save_base64_image(data_url, prefix='img'):
    try:
        header, data = data_url.split(',', 1)
        ext = 'png' if 'png' in header else 'jpg'
        fn  = f"{prefix}_{uuid.uuid4().hex[:12]}.{ext}"
        fp  = os.path.join(app.config['UPLOAD_FOLDER'], fn)
        with open(fp, 'wb') as fh:
            fh.write(base64.b64decode(data))
        return f'uploads/{fn}'
    except Exception:
        return ''

def can_update_photo(student_id):
    """
    Returns (allowed: bool, reason: str).
    Rules:
      - If locked by admin/warden → blocked
      - If never updated → allowed (first time)
      - If last update < 15 days ago → blocked
    """
    info = db.db_get_student_photo_status(student_id)
    if not info:
        return True, ''
    if info.get('PhotoUpdateLocked'):
        return False, 'Profile photo update has been locked by administration.'
    last = info.get('LastPhotoUpdate')
    if last is None:
        return True, ''   # first-time upload
    if isinstance(last, datetime):
        delta = datetime.now() - last
    else:
        delta = datetime.now() - datetime.combine(last, datetime.min.time())
    if delta.days < PHOTO_COOLDOWN_DAYS:
        remaining = PHOTO_COOLDOWN_DAYS - delta.days
        return False, f'You can update your photo again in {remaining} day(s).'
    return True, ''

# ---------------------------------------------------------------------------
# Init passwords
# ---------------------------------------------------------------------------
@app.route('/init-passwords')
def init_passwords():
    # Named credentials for original seed users
    creds = [
        ('admin@namal.edu.pk',       'admin#1219@'),
        ('nida.sultan@namal.edu.pk', 'nidanida12'),
        ('security@namal.edu.pk',    'security123'),
    ]
    for i in range(1, 16):
        creds.append((f'bscs24f{i:02d}@namal.edu.pk', '12121212'))

    for email, pw in creds:
        db.db_set_password_for_email(email, generate_password_hash(pw))

    # Fix ALL remaining users with PLACEHOLDER or empty hash → namal123
    fixed = db.db_fix_placeholder_passwords(generate_password_hash(TEMP_PASSWORD))

    return (f'<h2 style="font-family:sans-serif;color:#198754;padding:2rem;">'
            f'✓ Passwords initialised. Named users set. '
            f'All placeholder passwords set to <code>namal123</code>.'
            f'<br><a href="/">Go to Login</a></h2>')

# ---------------------------------------------------------------------------
# AUTH
# ---------------------------------------------------------------------------
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return _role_redirect(session.get('role'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        pw    = request.form.get('password', '')
        if not email or not pw:
            flash('Please enter email and password.', 'danger')
            return render_template('login.html')
        user = db.db_login(email)
        if user and check_password_hash(user['PasswordHash'], pw):
            session.permanent = True
            session.update(user_id=user['UserID'], name=user['Name'],
                           email=user['Email'], role=user['Role'])
            if user['Role'] == 'Student':
                session['student_id'] = user['StudentID']
                session['roll']       = user['RollNumber']
            elif user['Role'] == 'Warden':
                session['warden_id']  = user['WardenID']
            elif user['Role'] == 'Admin':
                session['admin_id']   = user['AdminID']
            return _role_redirect(user['Role'])
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')

def _role_redirect(role):
    m = {'Student': 'student_dashboard', 'Warden': 'warden_dashboard',
         'Security': 'security_dashboard', 'Admin': 'admin_dashboard'}
    return redirect(url_for(m.get(role, 'login')))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/security-gate')
def security_gate_direct():
    return redirect(url_for('security_pin'))


@app.route('/security/pin', methods=['GET', 'POST'])
def security_pin():
    global _gate_pin_state
    now          = datetime.now()
    locked_until = _gate_pin_state.get('locked_until')

    if locked_until and now < locked_until:
        remaining = int((locked_until - now).total_seconds() / 60) + 1
        return render_template('security_pin.html',
                               error=f'Too many failed attempts. Try again in {remaining} minute(s).',
                               locked=True, remaining=remaining)

    if request.method == 'POST':
        entered = request.form.get('pin', '').strip()
        correct = db.db_get_gate_pin()
        if entered == correct:
            _gate_pin_state['attempts']     = 0
            _gate_pin_state['locked_until'] = None
            session['gate_access'] = True
            return redirect(url_for('security_dashboard'))
        else:
            _gate_pin_state['attempts'] = _gate_pin_state.get('attempts', 0) + 1
            attempts = _gate_pin_state['attempts']
            if attempts >= 5:
                _gate_pin_state['locked_until'] = now + timedelta(minutes=5)
                _gate_pin_state['attempts']     = 0
                try:
                    db._raw_execute(
                        "INSERT INTO Notification (UserID, Type, Message) "
                        "SELECT AdminID, 'Security Alert', "
                        "'Gate screen locked after 5 failed PIN attempts.' "
                        "FROM SystemAdministrator LIMIT 1"
                    )
                except Exception:
                    pass
                return render_template('security_pin.html',
                                       error='Too many failed attempts. Locked for 5 minutes.',
                                       locked=True, remaining=5)
            left = 5 - attempts
            return render_template('security_pin.html',
                                   error=f'Wrong PIN. {left} attempt(s) remaining.',
                                   locked=False)
    return render_template('security_pin.html', error=None, locked=False)


def gate_access_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if not session.get('gate_access'):
            flash('Gate PIN required.', 'warning')
            return redirect(url_for('security_pin'))
        return f(*a, **kw)
    return dec

# ---------------------------------------------------------------------------
# STUDENT
# ---------------------------------------------------------------------------
@app.route('/student/dashboard')
@role_required('Student')
def student_dashboard():
    data = db.db_get_student_dashboard(session['student_id'])
    photo_ok, photo_msg = can_update_photo(session['student_id'])
    return render_template('student_dashboard.html', data=data,
                           photo_allowed=photo_ok, photo_msg=photo_msg)

@app.route('/student/mark-attendance', methods=['POST'])
@role_required('Student')
def mark_attendance():
    # Attendance window check: only 8 PM – 10 PM
    now_hour = datetime.now().hour
    start_h, end_h = db.db_get_attendance_window()
    if not (start_h <= now_hour < end_h):
        flash(f'Attendance can only be marked between {start_h}:00 and {end_h}:00.', 'danger')
        return redirect(url_for('student_dashboard'))

    # Block if student is currently on leave (outside hostel)
    if db.db_is_student_on_leave(session['student_id']):
        flash('You are currently on leave. Mark attendance after returning to hostel.', 'danger')
        return redirect(url_for('student_dashboard'))

    gps  = request.form.get('gps', '0,0')
    lat  = float(request.form.get('lat', 0))
    lon  = float(request.form.get('lon', 0))
    sb64 = request.form.get('selfie', '')
    sp   = save_base64_image(sb64, 'att') if sb64.startswith('data:') else ''
    result = db.db_mark_attendance(session['student_id'], gps, lat, lon, sp)
    flash(result or 'Attendance marked.', 'danger' if str(result).startswith('ERROR') else 'success')
    return redirect(url_for('student_dashboard'))

@app.route('/student/exit-application', methods=['POST'])
@role_required('Student')
def submit_exit():
    # Block if already has active exit application
    existing = db.db_has_active_exit_application(session['student_id'])
    if existing:
        flash(f'You already have an active exit application ({existing["ApprovalStatus"]}). '
              'Wait for it to complete before submitting a new one.', 'danger')
        return redirect(url_for('student_dashboard'))

    destination = request.form.get('destination', '')
    is_leave    = 1 if request.form.get('is_leave') else 0
    reason      = request.form.get('reason', '')
    dep_str     = request.form.get('departure_time', '')
    ret_str     = request.form.get('expected_return', '')
    try:    departure = datetime.strptime(dep_str, '%Y-%m-%dT%H:%M')
    except: departure = datetime.now()
    expected_return = None
    if ret_str:
        try: expected_return = datetime.strptime(ret_str, '%Y-%m-%dT%H:%M')
        except: pass
    result, _ = db.db_submit_exit(session['student_id'], destination, is_leave,
                                   reason, departure, expected_return)
    flash(result or 'Application submitted.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('student_dashboard'))

@app.route('/student/complaint', methods=['POST'])
@role_required('Student')
def submit_complaint():
    result = db.db_submit_complaint(session['student_id'],
                                    request.form.get('title', ''),
                                    request.form.get('description', ''),
                                    request.form.get('complaint_type', 'General'))
    flash(result or 'Complaint submitted.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('student_dashboard'))


@app.route('/student/my-complaints')
@role_required('Student')
def student_my_complaints():
    complaints  = db.db_get_student_complaints(session['student_id'])
    photo_ok, photo_msg = can_update_photo(session['student_id'])
    return render_template('student_dashboard.html',
                           show_tab='my_complaints',
                           my_complaints=complaints,
                           data=db.db_get_student_dashboard(session['student_id']),
                           photo_allowed=photo_ok, photo_msg=photo_msg)


@app.route('/student/my-exits')
@role_required('Student')
def student_my_exits():
    exits = db.db_get_student_exit_history(session['student_id'], 30)
    photo_ok, photo_msg = can_update_photo(session['student_id'])
    return render_template('student_dashboard.html',
                           show_tab='my_exits',
                           my_exits=exits,
                           data=db.db_get_student_dashboard(session['student_id']),
                           photo_allowed=photo_ok, photo_msg=photo_msg)


@app.route('/student/clear-exit-history', methods=['POST'])
@role_required('Student')
def clear_exit_history():
    result = db.db_clear_student_exit_history(session['student_id'])
    flash(result or 'History cleared.', 'success')
    return redirect(url_for('student_my_exits'))

@app.route('/student/notifications')
@role_required('Student')
def student_notifications():
    notifs = db.db_get_notifications(session['user_id'])
    db.db_mark_notifications_read(session['user_id'])
    photo_ok, photo_msg = can_update_photo(session['student_id'])
    return render_template('student_dashboard.html',
                           notifications=notifs, show_tab='notifications',
                           data=db.db_get_student_dashboard(session['student_id']),
                           photo_allowed=photo_ok, photo_msg=photo_msg)

@app.route('/student/update-profile', methods=['POST'])
@role_required('Student')
def update_profile():
    phone      = request.form.get('phone', '')
    photo_path = ''

    if 'profile_photo' in request.files:
        f = request.files['profile_photo']
        if f and f.filename and allowed_file(f.filename):
            allowed, msg = can_update_photo(session['student_id'])
            if not allowed:
                flash(msg, 'danger')
                return redirect(url_for('student_dashboard'))
            fn = secure_filename(f'profile_{session["student_id"]}_{uuid.uuid4().hex[:8]}.jpg')
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], fn))
            photo_path = f'uploads/{fn}'

    result = db.db_update_profile_photo(session['student_id'], phone, photo_path)
    flash(result or 'Profile updated.', 'success')
    return redirect(url_for('student_dashboard'))

@app.route('/student/change-password', methods=['POST'])
@role_required('Student')
def student_change_password():
    current = request.form.get('current_password', '')
    new_pw  = request.form.get('new_password', '')
    confirm = request.form.get('confirm_password', '')
    if new_pw != confirm:
        flash('Passwords do not match.', 'danger')
        return redirect(url_for('student_dashboard'))
    user = db.db_login(session['email'])
    if not user or not check_password_hash(user['PasswordHash'], current):
        flash('Current password is incorrect.', 'danger')
        return redirect(url_for('student_dashboard'))
    result = db.db_change_password(session['user_id'], generate_password_hash(new_pw))
    flash(result or 'Password changed.', 'success')
    return redirect(url_for('student_dashboard'))

@app.route('/api/notifications-count')
@login_required
def notifications_count():
    rows = db.db_get_notifications(session['user_id'])
    return jsonify({'count': sum(1 for r in rows if not r['IsRead'])})

@app.route('/api/attendance-chart')
@role_required('Student')
def attendance_chart():
    history = list(reversed(list(db.db_get_attendance_history(session['student_id'], 30))))
    return jsonify({
        'labels':   [str(r['Date']) for r in history],
        'values':   [1 if r['Status']=='Present' else .5 if r['Status']=='OnLeave' else 0 for r in history],
        'statuses': [r['Status'] for r in history]
    })

# ---------------------------------------------------------------------------
# WARDEN
# ---------------------------------------------------------------------------
@app.route('/warden/dashboard')
@role_required('Warden')
def warden_dashboard():
    att_detail   = db.db_get_attendance_detail(30)
    students_w   = db.db_get_all_students_with_photo()
    returned_today = db.db_get_returned_today()
    return render_template('warden_dashboard.html',
        pending_exits      = db.db_get_pending_exits(),
        pending_complaints = db.db_get_pending_complaints(),
        absent_today       = db.db_get_absent_today(),
        on_leave           = db.db_get_students_on_leave(),
        returned_today     = returned_today,
        allocations        = db.db_get_all_allocations(),
        rooms              = db.db_get_rooms(),
        all_students       = db.db_get_all_students(),
        students_w         = students_w,
        stats              = db.db_get_dashboard_stats(),
        all_exits          = db.db_get_all_exit_apps(),
        all_complaints     = db.db_get_all_complaints(),
        notifications      = db.db_get_notifications(session['user_id']),
        att_detail         = att_detail,
    )

@app.route('/warden/approve-exit', methods=['POST'])
@role_required('Warden')
def approve_exit():
    result = db.db_approve_exit(int(request.form['application_id']),
                                session['warden_id'],
                                request.form.get('action'),
                                request.form.get('remarks', ''))
    flash(result or 'Done.', 'success')
    return redirect(url_for('warden_dashboard'))

@app.route('/warden/resolve-complaint', methods=['POST'])
@role_required('Warden')
def resolve_complaint():
    result = db.db_resolve_complaint(int(request.form['complaint_id']),
                                     session['warden_id'],
                                     request.form.get('status'),
                                     request.form.get('remarks', ''))
    flash(result or 'Complaint updated.', 'success')
    return redirect(url_for('warden_dashboard'))

@app.route('/warden/allocate-room', methods=['POST'])
@role_required('Warden')
def allocate_room():
    result = db.db_allocate_room(int(request.form['student_id']),
                                  int(request.form['room_id']),
                                  session['warden_id'])
    flash(result or 'Room allocated.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('warden_dashboard'))

@app.route('/warden/toggle-photo-lock', methods=['POST'])
@role_required('Warden')
def warden_toggle_photo_lock():
    student_id = int(request.form.get('student_id'))
    locked     = int(request.form.get('locked', 0))
    result     = db.db_toggle_photo_lock(student_id, locked)
    flash(result or 'Updated.', 'success')
    return redirect(url_for('warden_dashboard'))

@app.route('/warden/lock-all-photos', methods=['POST'])
@role_required('Warden')
def warden_lock_all_photos():
    locked = int(request.form.get('locked', 0))
    count  = db.db_lock_all_photos(locked)
    action = 'locked' if locked else 'unlocked'
    flash(f'Photo updates {action} for {count} students.', 'success')
    return redirect(url_for('warden_dashboard'))

@app.route('/warden/change-password', methods=['POST'])
@role_required('Warden')
def warden_change_password():
    current = request.form.get('current_password', '')
    new_pw  = request.form.get('new_password', '')
    confirm = request.form.get('confirm_password', '')
    if new_pw != confirm:
        flash('Passwords do not match.', 'danger')
        return redirect(url_for('warden_dashboard'))
    user = db.db_login(session['email'])
    if not user or not check_password_hash(user['PasswordHash'], current):
        flash('Current password is incorrect.', 'danger')
        return redirect(url_for('warden_dashboard'))
    result = db.db_change_password(session['user_id'], generate_password_hash(new_pw))
    flash(result or 'Password changed.', 'success')
    return redirect(url_for('warden_dashboard'))

# AJAX – attendance detail for single student (warden)
@app.route('/api/warden/student-attendance/<int:student_id>')
@role_required('Warden')
def api_student_attendance(student_id):
    rows = db.db_get_student_attendance_detail(student_id, 30)
    result = []
    for r in rows:
        result.append({
            'Date':                  str(r['Date']),
            'VerificationTime':      str(r['VerificationTime']) if r['VerificationTime'] else '',
            'Status':                r['Status'],
            'VerificationMethod':    r['VerificationMethod'],
            'GPSLocation':           r['GPSLocation'] or '',
            'SuspiciousFlag':        r['SuspiciousFlag'],
            'AttendanceSelfiePath':  r['AttendanceSelfiePath'] or '',
            'ProfilePhotoPath':      r['ProfilePhotoPath'] or '',
            'StudentName':           r['StudentName'],
            'RollNumber':            r['RollNumber'],
        })
    return jsonify(result)

# ---------------------------------------------------------------------------
# SECURITY  (PIN required)
# ---------------------------------------------------------------------------
@app.route('/security/dashboard')
@gate_access_required
def security_dashboard():
    return render_template('security_dashboard.html',
                           gate_list=db.db_get_security_gate())

@app.route('/security/history')
@gate_access_required
def security_history():
    return render_template('security_dashboard.html',
                           gate_list=db.db_get_security_gate(),
                           history=db.db_get_gate_history(),
                           show_history=True)

@app.route('/security/history-json')
@gate_access_required
def security_history_json():
    rows = db.db_get_gate_history()
    result = []
    for h in rows:
        result.append({
            'LogID':            h['LogID'],
            'StudentName':      h['StudentName'],
            'RollNumber':       h['RollNumber'],
            'Department':       h.get('Department', ''),
            'ProfilePhotoPath': h.get('ProfilePhotoPath') or '',
            'ExitTime':         h['ExitTime'].strftime('%d %b %H:%M') if h.get('ExitTime') else '',
            'ActualReturnTime': h['ActualReturnTime'].strftime('%d %b %H:%M') if h.get('ActualReturnTime') else '',
            'LateReturnAlert':  bool(h.get('LateReturnAlert')),
        })
    return jsonify(result)

@app.route('/security/confirm-exit', methods=['POST'])
@gate_access_required
def security_confirm_exit():
    db.db_confirm_student_exit(int(request.form['application_id']),
                                int(request.form['student_id']))
    flash('Exit confirmed.', 'success')
    return redirect(url_for('security_dashboard'))

@app.route('/api/security/confirm-exit', methods=['POST'])
@gate_access_required
def api_security_confirm_exit():
    data = request.get_json(force=True)
    db.db_confirm_student_exit(int(data.get('application_id')), int(data.get('student_id')))
    return jsonify({'ok': True, 'msg': 'Exit confirmed.'})

@app.route('/security/record-return', methods=['POST'])
@gate_access_required
def security_record_return():
    result = db.db_record_return(int(request.form['student_id']),
                                  int(request.form['application_id']))
    flash(result or 'Student Return recorded.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('security_dashboard'))

@app.route('/api/security/record-return', methods=['POST'])
@gate_access_required
def api_security_record_return():
    data   = request.get_json(force=True)
    result = db.db_record_return(int(data.get('student_id')), int(data.get('application_id')))
    is_late = 'LATE' in str(result).upper()
    return jsonify({'ok': True, 'msg': result or 'Student Return recorded.', 'late': is_late})

# ---------------------------------------------------------------------------
# ADMIN
# ---------------------------------------------------------------------------
@app.route('/admin/dashboard')
@role_required('Admin')
def admin_dashboard():
    return render_template('admin_dashboard.html',
        students     = db.db_get_all_students_with_photo(),
        warden       = db.db_get_warden(),
        geofence     = db.db_get_geofence(),
        logs         = db.db_get_system_logs(50),
        stats        = db.db_get_dashboard_stats(),
        rooms        = db.db_get_rooms(),
        gate_history = db.db_get_gate_history(100),
        settings     = db.db_get_all_settings(),
    )


@app.route('/admin/save-settings', methods=['POST'])
@role_required('Admin')
def admin_save_settings():
    keys = [
        'attendance_start_hour', 'attendance_end_hour',
        'exit_before_5pm_auto_approve', 'exit_restricted_start_hour',
        'warden_approval_required', 'leave_auto_approve',
        'exit_expire_minutes', 'photo_cooldown_days',
        'max_pin_attempts', 'session_timeout_mins',
        'late_return_notify_warden', 'attendance_selfie_required',
        'attendance_gps_required', 'auto_absent_after_deadline',
        'hostel_name', 'academic_year',
    ]
    to_save = {}
    for k in keys:
        val = request.form.get(k)
        if val is not None:
            to_save[k] = val.strip()
    db.db_save_settings(to_save, session['admin_id'])

    # Update in-memory cooldown if changed
    global PHOTO_COOLDOWN_DAYS
    try:
        PHOTO_COOLDOWN_DAYS = int(to_save.get('photo_cooldown_days', PHOTO_COOLDOWN_DAYS))
    except Exception:
        pass

    flash('System settings saved successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/add-student', methods=['POST'])
@role_required('Admin')
def admin_add_student():
    name  = request.form.get('name', '')
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '')
    roll  = request.form.get('roll_number', '')
    dept  = request.form.get('department', 'Computer Science')
    sem   = int(request.form.get('semester', 1))
    # Always use namal123 as temp password
    result = db.db_add_student(name, email, generate_password_hash(TEMP_PASSWORD),
                               phone, roll, dept, sem, session['admin_id'])
    flash(result or 'Student added. Temp password: namal123',
          'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/update-student', methods=['POST'])
@role_required('Admin')
def admin_update_student():
    result = db.db_update_student(
        int(request.form['student_id']),
        request.form.get('name', ''),
        request.form.get('email', '').strip().lower(),
        request.form.get('phone', ''),
        request.form.get('roll_number', ''),
        request.form.get('department', ''),
        int(request.form.get('semester', 1)),
        session['admin_id']
    )
    flash(result or 'Student updated.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-student', methods=['POST'])
@role_required('Admin')
def admin_delete_student():
    result = db.db_delete_student(int(request.form['student_id']), session['admin_id'])
    flash(result or 'Student deleted.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reset-student-password', methods=['POST'])
@role_required('Admin')
def admin_reset_student_password():
    sid    = int(request.form['student_id'])
    new_pw = request.form.get('new_password', TEMP_PASSWORD).strip() or TEMP_PASSWORD
    result = db.db_admin_reset_student_password(sid, generate_password_hash(new_pw), session['admin_id'])
    flash(result or f'Password reset to: {new_pw}', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/toggle-photo-lock', methods=['POST'])
@role_required('Admin')
def admin_toggle_photo_lock():
    student_id = int(request.form.get('student_id'))
    locked     = int(request.form.get('locked', 0))
    result     = db.db_toggle_photo_lock(student_id, locked)
    flash(result or 'Updated.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/lock-all-photos', methods=['POST'])
@role_required('Admin')
def admin_lock_all_photos():
    locked = int(request.form.get('locked', 0))
    count  = db.db_lock_all_photos(locked)
    action = 'locked' if locked else 'unlocked'
    flash(f'Photo updates {action} for {count} students.', 'success')
    return redirect(url_for('admin_dashboard'))

# Rooms
@app.route('/admin/add-room', methods=['POST'])
@role_required('Admin')
def admin_add_room():
    result = db.db_add_room(request.form.get('room_number','').strip(),
                            int(request.form.get('capacity', 2)), session['admin_id'])
    flash(result or 'Room added.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/update-room', methods=['POST'])
@role_required('Admin')
def admin_update_room():
    result = db.db_update_room(int(request.form['room_id']),
                               request.form.get('room_number','').strip(),
                               int(request.form.get('capacity', 2)),
                               request.form.get('room_status','Available'),
                               session['admin_id'])
    flash(result or 'Room updated.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-room', methods=['POST'])
@role_required('Admin')
def admin_delete_room():
    result = db.db_delete_room(int(request.form['room_id']), session['admin_id'])
    flash(result or 'Room deleted.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

# Batch import
@app.route('/admin/import-students', methods=['POST'])
@role_required('Admin')
def admin_import_students():
    f = request.files.get('csv_file')
    if not f or not allowed_csv(f.filename):
        flash('Please upload a valid .csv file.', 'danger')
        return redirect(url_for('admin_dashboard'))
    try:
        stream  = io.StringIO(f.stream.read().decode('utf-8-sig'))
        reader  = csv.DictReader(stream)
        req_cols = {'name','email','roll_number','department','semester'}
        if not req_cols.issubset({c.strip().lower() for c in reader.fieldnames or []}):
            flash('CSV missing: name, email, roll_number, department, semester', 'danger')
            return redirect(url_for('admin_dashboard'))
        ok, errs = 0, []
        for i, row in enumerate(reader, 2):
            name  = row.get('name','').strip()
            email = row.get('email','').strip().lower()
            roll  = row.get('roll_number','').strip()
            if not name or not email or not roll:
                errs.append(f'Row {i}: missing fields'); continue
            res = db.db_add_student(
                name, email, generate_password_hash(TEMP_PASSWORD),
                row.get('phone','').strip(), roll,
                row.get('department','Computer Science').strip(),
                int(row.get('semester',1) or 1), session['admin_id']
            )
            if res and 'ERROR' in str(res): errs.append(f'Row {i}: {res}')
            else: ok += 1
        msg = f'{ok} student(s) imported. Temp password: {TEMP_PASSWORD}'
        flash(msg + (f' | {len(errs)} errors.' if errs else ''), 'warning' if errs else 'success')
    except Exception as e:
        flash(f'Import failed: {e}', 'danger')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/download-template')
@role_required('Admin')
def download_template():
    content = ('name,email,roll_number,department,semester,phone\n'
               'Ayesha Khan,ayesha@namal.edu.pk,NUM-BSCS-2024-20,Computer Science,2,0300-1234567\n'
               'Sara Malik,sara@namal.edu.pk,NUM-BSCS-2024-21,Computer Science,2,0300-7654321\n')
    return Response(content, mimetype='text/csv',
                    headers={'Content-Disposition':'attachment; filename=students_template.csv'})

# Warden management
@app.route('/admin/update-warden', methods=['POST'])
@role_required('Admin')
def admin_update_warden():
    db.db_update_warden_info(int(request.form['warden_id']),
                             request.form.get('name',''),
                             request.form.get('phone',''),
                             request.form.get('office_phone',''),
                             session['admin_id'])
    flash('Warden info updated.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/update-warden-password', methods=['POST'])
@role_required('Admin')
def admin_update_warden_password():
    new_pw  = request.form.get('new_password','')
    confirm = request.form.get('confirm_password','')
    if new_pw != confirm:
        flash('Passwords do not match.', 'danger')
        return redirect(url_for('admin_dashboard'))
    result = db.db_update_warden_password(int(request.form['warden_id']),
                                          generate_password_hash(new_pw), session['admin_id'])
    flash(result or 'Warden password updated.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/update-geofence', methods=['POST'])
@role_required('Admin')
def admin_update_geofence():
    result = db.db_update_geofence(
        int(request.form.get('geofence_id') or 0),
        request.form.get('boundary_name','Girls Hostel Premises'),
        float(request.form.get('latitude', 32.478)),
        float(request.form.get('longitude', 71.968)),
        float(request.form.get('radius_meters', 200)),
        session['admin_id'])
    flash(result or 'Geofence updated.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/change-password', methods=['POST'])
@role_required('Admin')
def admin_change_password():
    current = request.form.get('current_password','')
    new_pw  = request.form.get('new_password','')
    confirm = request.form.get('confirm_password','')
    if new_pw != confirm:
        flash('Passwords do not match.', 'danger')
        return redirect(url_for('admin_dashboard'))
    user = db.db_login(session['email'])
    if not user or not check_password_hash(user['PasswordHash'], current):
        flash('Current password incorrect.', 'danger')
        return redirect(url_for('admin_dashboard'))
    result = db.db_change_password(session['user_id'], generate_password_hash(new_pw))
    flash(result or 'Password changed.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-history', methods=['POST'])
@role_required('Admin')
def admin_delete_history():
    result = db.db_delete_gate_history(int(request.form['log_id']), session['admin_id'])
    flash(result or 'Record deleted.', 'danger' if 'ERROR' in str(result) else 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/api/student/<int:student_id>')
@role_required('Admin')
def api_get_student(student_id):
    students = db.db_get_all_students_with_photo()
    s = next((x for x in students if x['StudentID'] == student_id), None)
    if s:
        return jsonify({k: str(v) if hasattr(v,'isoformat') else v for k,v in s.items()})
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/room/<int:room_id>')
@role_required('Admin')
def api_get_room(room_id):
    rooms = db.db_get_rooms()
    r = next((x for x in rooms if x['RoomID'] == room_id), None)
    if r:
        return jsonify({k: str(v) if hasattr(v,'isoformat') else v for k,v in r.items()})
    return jsonify({'error': 'Not found'}), 404

@app.route('/admin/update-gate-pin', methods=['POST'])
@role_required('Admin')
def admin_update_gate_pin():
    new_pin = request.form.get('new_pin', '').strip()
    confirm = request.form.get('confirm_pin', '').strip()
    if not new_pin.isdigit() or not (4 <= len(new_pin) <= 6):
        flash('PIN must be 4-6 digits.', 'danger')
        return redirect(url_for('admin_dashboard'))
    if new_pin != confirm:
        flash('PINs do not match.', 'danger')
        return redirect(url_for('admin_dashboard'))
    db.db_set_gate_pin(new_pin, session['admin_id'])
    flash(f'Gate PIN updated successfully.', 'success')
    return redirect(url_for('admin_dashboard'))


# Warden reports (download CSV)
@app.route('/warden/report/attendance')
@role_required('Warden')
def warden_report_attendance():
    start = request.args.get('start', str(datetime.now().date() - timedelta(days=30)))
    end   = request.args.get('end',   str(datetime.now().date()))
    rows  = db.db_get_attendance_report(start, end)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Name', 'Roll No', 'Department', 'Date', 'Status', 'Time', 'Method'])
    for r in rows:
        writer.writerow([r['Name'], r['RollNumber'], r['Department'],
                         r['Date'], r['Status'], r['VerificationTime'], r['VerificationMethod']])
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=attendance_{start}_to_{end}.csv'})


@app.route('/warden/report/rooms')
@role_required('Warden')
def warden_report_rooms():
    start = request.args.get('start', str(datetime.now().date() - timedelta(days=30)))
    end   = request.args.get('end',   str(datetime.now().date()))
    rows  = db.db_get_room_report(start, end)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Room', 'Capacity', 'Occupancy', 'Status', 'Student', 'Roll', 'Allocated', 'Deallocated', 'AllocStatus'])
    for r in rows:
        writer.writerow([r['RoomNumber'], r['Capacity'], r['CurrentOccupancy'], r['RoomStatus'],
                         r['StudentName'], r['RollNumber'], r['AllocationDate'],
                         r['DeallocationDate'], r['AllocStatus']])
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=rooms_{start}_to_{end}.csv'})


@app.route('/warden/report/exits')
@role_required('Warden')
def warden_report_exits():
    start = request.args.get('start', str(datetime.now().date() - timedelta(days=30)))
    end   = request.args.get('end',   str(datetime.now().date()))
    rows  = db.db_get_exit_report(start, end)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Student', 'Roll', 'Destination', 'Type', 'Departure', 'ExpReturn',
                     'Status', 'ExitTime', 'ReturnTime', 'Late'])
    for r in rows:
        writer.writerow([r['StudentName'], r['RollNumber'], r['Destination'],
                         'Leave' if r['IsOnLeave'] else 'Short Exit',
                         r['DepartureTime'], r['ExpectedReturnTime'], r['ApprovalStatus'],
                         r['ExitTime'], r['ActualReturnTime'],
                         'YES' if r['LateReturnAlert'] else 'NO'])
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=exits_{start}_to_{end}.csv'})


# Warden: view full student details
@app.route('/warden/student/<int:student_id>')
@role_required('Warden')
def warden_student_detail(student_id):
    student  = db.db_get_student_full_detail(student_id)
    att_hist = db.db_get_student_attendance_detail(student_id, 30)
    exits    = db.db_get_all_exit_apps()
    s_exits  = [e for e in exits if e['StudentID'] == student_id]
    return render_template('warden_student_detail.html',
                           student=student, att_hist=att_hist, exits=s_exits)


# Team / About page
@app.route('/team')
def team_dashboard():
    return render_template('team.html')


# ---------------------------------------------------------------------------
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
