/**
 * main.js – SHMS Frontend JavaScript
 * Handles: Camera capture, GPS detection, UI helpers
 */

'use strict';

/* =========================================================
   CAMERA & SELFIE CAPTURE  (Attendance)
   ========================================================= */

let cameraStream = null;

function initAttendanceCamera() {
  const startBtn      = document.getElementById('startCamera');
  const captureBtn    = document.getElementById('captureSelfie');
  const retakeBtn     = document.getElementById('retakeSelfie');
  const video         = document.getElementById('camera');
  const canvas        = document.getElementById('selfieCanvas');
  const preview       = document.getElementById('selfiePreview');
  const placeholder   = document.getElementById('cameraPlaceholder');
  const selfieField   = document.getElementById('selfieField');
  const getGPSBtn     = document.getElementById('getGPS');
  const gpsText       = document.getElementById('gpsText');
  const gpsField      = document.getElementById('gpsField');
  const latField      = document.getElementById('latField');
  const lonField      = document.getElementById('lonField');
  const gpsStatus     = document.getElementById('gpsStatus');

  if (!startBtn) return;  // Not on attendance page

  // ---- Camera ----
  startBtn.addEventListener('click', async () => {
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }
      });
      video.srcObject = cameraStream;
      video.classList.remove('d-none');
      video.style.display = 'block';
      if (placeholder) placeholder.style.display = 'none';
      startBtn.classList.add('d-none');
      captureBtn.classList.remove('d-none');
    } catch (err) {
      showAlert('Camera access denied or not available. ' + err.message, 'warning');
    }
  });

  captureBtn.addEventListener('click', () => {
    if (!canvas || !video) return;
    canvas.width  = video.videoWidth  || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const dataURL = canvas.toDataURL('image/jpeg', 0.85);
    if (selfieField)  selfieField.value = dataURL;
    if (preview) {
      preview.src = dataURL;
      preview.classList.remove('d-none');
    }
    video.style.display = 'none';
    captureBtn.classList.add('d-none');
    retakeBtn.classList.remove('d-none');

    // Stop stream
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      cameraStream = null;
    }
  });

  retakeBtn.addEventListener('click', () => {
    if (selfieField) selfieField.value = '';
    if (preview)    preview.classList.add('d-none');
    video.style.display = 'none';
    retakeBtn.classList.add('d-none');
    captureBtn.classList.add('d-none');
    startBtn.classList.remove('d-none');
    if (placeholder) placeholder.style.display = '';
  });

  // ---- GPS ----
  if (getGPSBtn) {
    getGPSBtn.addEventListener('click', () => {
      detectGPS();
    });
  }

  // Auto-detect GPS on page load (silently)
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => { setGPSFields(pos, gpsField, latField, lonField, gpsText, gpsStatus); },
      (err) => { if (gpsText) gpsText.textContent = 'Auto-detect failed. Click "Detect My Location".'; },
      { timeout: 10000 }
    );
  }
}

function detectGPS() {
  const gpsText   = document.getElementById('gpsText');
  const gpsField  = document.getElementById('gpsField');
  const latField  = document.getElementById('latField');
  const lonField  = document.getElementById('lonField');
  const gpsStatus = document.getElementById('gpsStatus');

  if (!navigator.geolocation) {
    if (gpsText) gpsText.textContent = 'Geolocation not supported by this browser.';
    return;
  }

  if (gpsText) gpsText.textContent = 'Detecting location...';
  if (gpsStatus) {
    gpsStatus.className = 'alert alert-warning small mb-3';
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => { setGPSFields(pos, gpsField, latField, lonField, gpsText, gpsStatus); },
    (err) => {
      const messages = {
        1: 'Location permission denied. Please allow location access in browser settings.',
        2: 'Position unavailable. Please try again.',
        3: 'Location request timed out. Please try again.',
      };
      if (gpsText) gpsText.textContent = messages[err.code] || 'Location error: ' + err.message;
      if (gpsStatus) gpsStatus.className = 'alert alert-danger small mb-3';
    },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
  );
}

function setGPSFields(pos, gpsField, latField, lonField, gpsText, gpsStatus) {
  const lat = pos.coords.latitude.toFixed(7);
  const lon = pos.coords.longitude.toFixed(7);
  const acc = Math.round(pos.coords.accuracy);

  if (gpsField)  gpsField.value = lat + ',' + lon;
  if (latField)  latField.value = lat;
  if (lonField)  lonField.value = lon;
  if (gpsText)   gpsText.textContent = `Location: ${lat}, ${lon} (±${acc}m)`;
  if (gpsStatus) gpsStatus.className = 'alert alert-success small mb-3';
}

/* =========================================================
   ATTENDANCE FORM SUBMISSION GUARD
   ========================================================= */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('attendanceForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      const selfie = document.getElementById('selfieField');
      const lat    = document.getElementById('latField');

      if (!selfie || !selfie.value) {
        e.preventDefault();
        showAlert('Please capture a selfie before submitting attendance.', 'warning');
        return;
      }
      if (!lat || parseFloat(lat.value) === 0) {
        // Allow submission with GPS 0,0 (server will decide based on config)
        // Just warn
        const confirmed = confirm(
          'GPS location not detected. Your attendance may be rejected if you are outside the geofence.\n\nContinue anyway?'
        );
        if (!confirmed) e.preventDefault();
      }
    });
  }
});

/* =========================================================
   UTILITY
   ========================================================= */

function showAlert(msg, type = 'info') {
  const container = document.getElementById('flashContainer') || document.body;
  const div = document.createElement('div');
  div.className = `alert alert-${type} alert-dismissible fade show mt-2 shadow-sm`;
  div.role = 'alert';
  div.innerHTML = `${msg}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
  container.prepend(div);
  setTimeout(() => {
    try { bootstrap.Alert.getOrCreateInstance(div).close(); } catch (e) {}
  }, 6000);
}

/* Keep session alive by pinging every 20 minutes */
setInterval(() => {
  fetch('/api/notifications-count').catch(() => {});
}, 1200000);
