# Smart Hostel Management System (SHMS)
**Namal University Girls Hostel – Database Systems Project**

---

## Prerequisites

| Tool | Version |
|------|---------|
| Python | 3.10+ |
| MySQL | 8.0+ |
| pip | latest |

---

## Step-by-Step Setup

### 1. Install Python packages

```bash
pip install -r requirements.txt
```

### 2. Create the database (run SQL files IN ORDER)

Open MySQL Workbench or MySQL CLI and run:

```sql
SOURCE path/to/dbDDL.sql;
SOURCE path/to/dbDML.sql;
```

Or from command line:

```bash
mysql -u root -p < dbDDL.sql
mysql -u root -p < dbDML.sql
```

**Both files must be run in order.** `dbDDL.sql` creates the full schema (tables, views, stored procedures, triggers, events). `dbDML.sql` inserts seed data.

### 3. Configure database password

Open `app.py` and set your MySQL root password (already set to `helenhelen`):

```python
MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'helenhelen'),
```

Or set environment variable:
```
set MYSQL_PASSWORD=yourpassword
```

### 4. Start the application

```bash
python app.py
```

### 5. Initialise passwords (ONE TIME ONLY)

Visit this URL once after starting:

```
http://127.0.0.1:5000/init-passwords
```

This hashes all seed passwords. Without this step, no one can log in.

### 6. Open the app

```
http://127.0.0.1:5000
```

### 7. Access from Android via ZeroTier

Since ZeroTier is installed on both the laptop and your Android:

1. Note your ZeroTier IP (shown in ZeroTier app — usually `10.x.x.x`)
2. Make sure both devices are on the same ZeroTier network
3. On Android, open browser and go to:
   ```
   http://10.x.x.x:5000
   ```
4. The app binds to `0.0.0.0:5000` so it accepts connections from all interfaces

---

## Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@namal.edu.pk | admin#1219@ |
| Warden | nida.sultan@namal.edu.pk | nidanida12 |
| Security | *(button on login page — no password)* | — |
| Students | bscs24f01@namal.edu.pk … bscs24f15@namal.edu.pk | 12121212 |

**New students added by admin get temp password:** `namal123`

---

## Project Structure

```
HELEN X SHMS/
├── app.py                  Flask routes (all 4 roles)
├── database.py             DB wrapper (all queries via SPs)
├── dbDDL.sql               Complete schema: tables, views, SPs, triggers, events
├── dbDML.sql               Seed data (15 girl students, rooms, admin, warden)
├── requirements.txt
├── README.md
├── static/
│   ├── css/style.css       Green theme
│   ├── js/main.js          Camera, GPS, UI helpers
│   ├── images/             namal-logo.png (add manually)
│   └── uploads/            Auto-created – profile photos & selfies
└── templates/
    ├── base.html
    ├── login.html
    ├── student_dashboard.html
    ├── warden_dashboard.html
    ├── security_dashboard.html
    └── admin_dashboard.html
```

---

## Key Features

### Student
- Mark attendance with camera selfie + GPS geofence validation
- Exit before 5 PM → **auto-approved**, must return by 5 PM
- Exit at/after 5 PM or leave → **warden approval required**
- Late return → automatic notification to warden with student name and roll number
- Profile photo: first upload free, then once every **15 days**
- Admin/Warden can **lock** photo updates for any student
- Temp password `namal123` shows a banner prompting password change

### Warden
- Approve/reject exit applications
- Click any student in Attendance tab → see their 30-day history with **profile photo + attendance selfie side by side**
- Click either photo to open full-size lightbox
- Lock/unlock profile photo updates per student
- Resolve complaints, manage room allocations

### Security Gate
- No login required
- Large photo cards (120×120px) with big text for easy visual verification
- **Confirm Exit** button: student moves from "Ready" to "Exited" status instantly (no page reload)
- **Record Return** button: student card **disappears** from Active view, moves to History automatically
- Late returns show red toast alert
- **History tab**: all returned students with exit/return times and On Time/LATE status
- History loads via AJAX (no page reload)
- **English/Urdu** language toggle (persists across refresh)
- Dark/light mode toggle

### Admin
- Add students (temp password: `namal123`)
- **Hard delete** students (permanently removes all linked data)
- **Reset student password** (set any password, default `namal123`)
- **Lock/unlock** student profile photo updates
- Batch CSV import (download template button)
- Full room CRUD (add, edit, delete empty rooms)
- Gate history tab with delete capability
- System change logs (full audit trail)

---

## Business Rules

| Rule | Description |
|------|-------------|
| BR-1 | Attendance only within GPS geofence |
| BR-2 | Camera selfie required at attendance time |
| BR-3 | 10 PM deadline; auto-absent if not marked |
| BR-4 | Leave apps auto-mark OnLeave |
| BR-5 | Exit before 5 PM = auto-approved; at/after 5 PM = warden approval |
| BR-6 | Late return = notification to warden with student name + roll |
| BR-7 | Security sees only approved exits |
| BR-8 | Record Return removes card from active, moves to history |
| BR-9 | All admin actions logged in SystemChangeLog |
| BR-10 | Single warden handles all approvals |
| BR-11 | Photo update: free on first upload, then once per 15 days |
| BR-12 | Admin/warden can lock photo updates |
| BR-13 | Attendance selfies retained for 30 days then path auto-cleared |
| BR-14 | New students get temp password `namal123` |
| BR-15 | Admin can hard-delete students (permanent) |

---

## Team

| Name | Roll Number |
|------|-------------|
| Muhammad Ahmad | NUM-BSCS-2024-44 |
| Asad Ullah Khan | NUM-BSCS-2024-17 |
| Maryam Rashid | NUM-BSCS-2024-33 |

**Submitted to:** Ms. Asiya Batool  
**Course:** Database Systems — Namal University, Mianwali
